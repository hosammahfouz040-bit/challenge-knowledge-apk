// سكربت تحقق آلي: سلامة بنك الأسئلة وعدم التكرار وصحة الإجابات والمولّد
import { BANK, CATEGORIES } from '../src/data';
import { generatePuzzles } from '../src/lib/generator';
import { levelFromXp, levelProgress } from '../src/lib/utils';
import { validatePack } from '../src/lib/refresh';
import { generateForCategory, generateMixedPack, GENERATABLE_CATEGORIES } from '../src/lib/gengeneral';

let failures = 0;
const fail = (msg: string) => { failures++; console.log('✗', msg); };
const ok = (msg: string) => console.log('✓', msg);

// 1) أعداد الأقسام
const counts: Record<string, number> = {};
for (const q of BANK) counts[q.category] = (counts[q.category] ?? 0) + 1;
console.log('\n— أعداد الأسئلة الفعلية —');
for (const c of CATEGORIES) console.log(`  ${c.name}: ${counts[c.id] ?? 0}`);
console.log(`  الإجمالي: ${BANK.length}`);
const general = (counts.science ?? 0) + (counts.culture ?? 0) + (counts.geohist ?? 0) + (counts.space ?? 0);
console.log(`  الأقسام العامة الأربعة: ${general}`);
if (general < 300) fail('الأقسام العامة أقل من 300');

// 2) التكرار
const seen = new Map<string, string>();
for (const q of BANK) {
  if (seen.has(q.text)) fail(`سؤال مكرر: «${q.text}» (${seen.get(q.text)} و ${q.id})`);
  seen.set(q.text, q.id);
}
ok('فحص تكرار نصوص الأسئلة');

// 3) سلامة كل سؤال
for (const q of BANK) {
  if (!q.explanation || q.explanation.length < 10) fail(`تفسير قصير/مفقود: ${q.id}`);
  if (q.type === 'mcq' || q.type === 'image') {
    if (q.options.length !== 4) fail(`عدد الخيارات ليس 4: ${q.id}`);
    if (new Set(q.options).size !== 4) fail(`خيارات مكررة داخل السؤال: ${q.id} «${q.text}»`);
    if (q.options[q.answer] !== q.correctText) fail(`الإجابة الصحيحة غير متطابقة مع الفهرس: ${q.id}`);
  }
  if (q.type === 'image' && !q.image?.startsWith('https://')) fail(`صورة غير صالحة: ${q.id}`);
  if (q.type === 'order') {
    const years = (q.events ?? []).map((e) => e.year);
    const sorted = [...years].sort((a, b) => a - b);
    if (JSON.stringify(years) !== JSON.stringify(sorted)) fail(`أحداث الترتيب غير مرتبة في البيانات: ${q.id}`);
    if (new Set(years).size !== years.length) fail(`سنوات مكررة داخل سؤال ترتيب: ${q.id}`);
  }
  if (q.type === 'map' && !q.continent) fail(`سؤال خريطة بلا قارة: ${q.id}`);
}
ok('فحص سلامة الخيارات والإجابات والتفسيرات والترتيب');

// 4) مولّد الألغاز: 200 لغز بإجابات صحيحة وخيارات فريدة
const gen = generatePuzzles(200, 42, 2);
if (gen.length !== 200) fail(`المولّد أنتج ${gen.length} فقط`);
for (const g of gen) {
  if (g.options.length !== 4 || new Set(g.options).size !== 4) fail(`خيارات مولّدة غير فريدة: ${g.text}`);
  if (g.options[g.answer] !== g.correctText) fail(`إجابة مولّدة خاطئة: ${g.text}`);
}
ok('فحص مولّد الألغاز (200 لغز)');

// 5) المستويات
if (levelFromXp(0) !== 1 || levelFromXp(120) !== 2 || levelFromXp(480) !== 3) fail('حساب المستويات خاطئ');
const lp = levelProgress(200);
if (lp.level !== 2 || lp.pct < 0 || lp.pct > 100) fail('تقدم المستوى خاطئ');
ok('فحص نظام المستويات والخبرة');

// 6) التحقق من حزم الأسئلة الخارجية
const res = validatePack([
  { text: 'سؤال تجريبي للتحقق من الحزمة الخارجية؟', options: ['أ', 'ب', 'ج', 'د'], answer: 2, explanation: 'تفسير تجريبي' },
  { text: 'سؤال تجريبي للتحقق من الحزمة الخارجية؟', options: ['أ', 'ب', 'ج', 'د'], answer: 2 },
  { text: 'ناقص', options: ['أ'], answer: 0 },
], []);
if (res.added.length !== 1 || res.skipped !== 2) fail(`التحقق من الحزم: أُضيف ${res.added.length} وتُجاوز ${res.skipped}`);
else ok('فحص التحقق من الحزم الخارجية (إضافة/تكرار/نقص)');

// 7) الأقسام الجديدة مزودة كلها بمعلومات «معرفة المزيد»
for (const cat of ['religion', 'health', 'sports'] as const) {
  const qs = BANK.filter((q) => q.category === cat);
  if (qs.length < 30) fail(`القسم الجديد ${cat} أقل من المتوقع: ${qs.length}`);
  const missing = qs.filter((q) => (q.more ?? '').length < 25);
  if (missing.length) fail(`أسئلة بلا معلومات إضافية في ${cat}: ${missing.slice(0, 5).map((q) => q.id).join(', ')}`);
}
const withMore = BANK.filter((q) => (q.more ?? '').length >= 10).length;
const withTopic = BANK.filter((q) => (q.topic ?? '').length >= 2).length;
console.log(`  أسئلة تحمل «معرفة المزيد»: ${withMore} · أسئلة بموضوع بحث خارجي: ${withTopic}`);
ok('فحص الأقسام الجديدة ومعلومات المزيد');

// 8) المولّد الشامل: أسئلة صحيحة ومتحقق منها في كل قسم
const bankTexts = new Set(BANK.map((x) => x.text));
for (const cat of GENERATABLE_CATEGORIES) {
  const qs = generateForCategory(cat, 40, 5000 + cat.length * 31, new Set(bankTexts), true);
  if (qs.length < 10) fail(`توليد قسم ${cat} أنتج ${qs.length} سؤالًا فقط`);
  const texts = new Set<string>();
  for (const g of qs) {
    if (g.category !== cat) fail(`سؤال مولّد بقسم خاطئ: ${g.id}`);
    const sig = g.type === 'order' ? g.correctText : g.text;
    if (texts.has(sig)) fail(`تكرار داخل المولّد (${cat}): ${g.text}`);
    texts.add(sig);
    if (g.type === 'mcq') {
      if (g.options.length !== 4 || new Set(g.options).size !== 4) fail(`خيارات مولّدة غير سليمة (${cat}): ${g.text}`);
      if (g.options[g.answer] !== g.correctText) fail(`إجابة مولّدة غير متطابقة (${cat}): ${g.text}`);
    } else if (g.type === 'map') {
      if (!g.continent) fail(`سؤال خريطة مولّد بلا قارة: ${g.text}`);
    } else if (g.type === 'order') {
      const ys = (g.events ?? []).map((e) => e.year);
      const sorted = [...ys].sort((a, b) => a - b);
      if (JSON.stringify(ys) !== JSON.stringify(sorted)) fail(`ترتيب مولّد غير مرتب في البيانات: ${g.text}`);
    }
  }
}
const mixed = generateMixedPack(66, 777, new Set(bankTexts), true);
const mixedCats = new Set(mixed.map((g) => g.category));
if (mixed.length < 60) fail(`الحزمة الشاملة أنتجت ${mixed.length} فقط`);
if (mixedCats.size < 9) fail(`الحزمة الشاملة غطت ${mixedCats.size} أقسام فقط`);
console.log(`  الحزمة الشاملة: ${mixed.length} سؤالًا عبر ${mixedCats.size} قسمًا`);
ok('فحص المولّد الشامل لكل الأقسام');

console.log(failures === 0 ? '\nكل الفحوصات نجحت ✔' : `\nتوجد ${failures} مشكلة ✘`);
process.exit(failures ? 1 : 0);
