# بناء نسخة Android (APK) لتطبيق «تحدي المعرفة»

هذا الملف يوثّق بصدق حالة تجهيز Android وخطوات إنتاج الـ APK. التطبيق نفسه ويب (React + Vite) يعمل كاملًا دون إنترنت بعد تحميله، ويُغلَّف لنظام Android باستخدام Capacitor.

## ما تم تجهيزه فعليًا في هذا المشروع
- `capacitor.config.json`: إعدادات Capacitor جاهزة (المعرف `com.tahadi.alma3rifa`، الاسم «تحدي المعرفة»، مجلد الويب `dist`).
- `public/icon.png`: أيقونة أصلية للتطبيق (تُستخدم أيضًا داخل الواجهة وكأيقونة اختصار).
- `.github/workflows/build-apk.yml`: خطة GitHub Actions كاملة تبني الويب ثم تضيف منصة Android وتبني `app-debug.apk` وترفعه كـ Artifact.
- بناء الويب للإنتاج (`npm run build`) مُختبَر وناجح محليًا داخل بيئة التطوير.

## ما لم يُنفَّذ داخل بيئة التطوير الحالية (بصراحة)
لم يُنشأ ملف APK فعلي داخل هذه البيئة لأنها لا تحتوي Android SDK ولا أدوات Gradle/JDK اللازمة لبناء Android. لم يُدَّعَ غير ذلك. لإنتاج الـ APK اتبع إحدى الطريقتين التاليتين.

## الطريقة الأولى: GitHub Actions (الأسهل — دون تثبيت أي شيء)
1. ارفع المشروع إلى مستودع GitHub (الفرع `main`).
2. افتح تبويب **Actions** واختر خطة **Build Android APK (تحدي المعرفة)**.
3. اضغط **Run workflow** وانتظر اكتمال البناء (عدة دقائق).
4. من صفحة التشغيل الناجح حمّل الـ Artifact باسم `tahadi-alma3rifa-debug-apk` واستخرج `app-debug.apk`.
5. ثبّت الملف على هاتف Samsung A04 (قد تحتاج تفعيل «التثبيت من مصادر غير معروفة» لأنه بناء Debug).

## الطريقة الثانية: البناء المحلي على جهازك
المتطلبات: Node.js 20+، ‏JDK 17، ‏Android Studio أو Android SDK (مع قبول التراخيص).

```bash
npm install
npm run build
npm install -D @capacitor/cli @capacitor/core @capacitor/android
npx cap add android
npx cap sync android
cd android
./gradlew assembleDebug        # في ويندوز: gradlew.bat assembleDebug
# الناتج: android/app/build/outputs/apk/debug/app-debug.apk
```

لتوليد أيقونات Android بكل المقاسات من الأيقونة الأصلية اختياريًا:
```bash
npm install -D @capacitor/assets
# ضع نسخة 1024×1024 من الأيقونة في assets/icon.png ثم:
npx capacitor-assets generate --android
```

## بناء إصدار موقّع للنشر (Release)
1. أنشئ مفتاح توقيع: `keytool -genkeypair -keystore tahadi.keystore -alias tahadi -keyalg RSA -keysize 2048 -validity 10000`
2. أضف بياناته في `android/gradle.properties` عبر متغيرات بيئة (لا تضع كلمات المرور داخل المستودع).
3. ابنِ: `./gradlew assembleRelease` أو `bundleRelease` لصيغة AAB المناسبة لمتجر Google Play.

## ملاحظات الخصوصية
التطبيق لا يطلب أي أذونات Android إضافية ولا يجمع بيانات؛ تقدم اللاعب يُحفظ في التخزين المحلي للجهاز فقط.
