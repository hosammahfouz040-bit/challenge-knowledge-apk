import { useState, type ReactNode } from 'react';
import {
  FlaskConical, BookOpenText, Earth, Rocket, Map as MapIcon, Image as ImageIcon, Brain, History,
  GraduationCap, User, BookOpen, Crown, Star, Lightbulb, Cat, Sparkles, ChevronRight, X,
  MoonStar, HeartPulse, Trophy, ChevronDown, ExternalLink, BookMarked,
  type LucideIcon,
} from 'lucide-react';
import type { Question } from '../types';

export const CATEGORY_ICONS: Record<string, LucideIcon> = {
  flask: FlaskConical,
  book: BookOpenText,
  globe: Earth,
  rocket: Rocket,
  map: MapIcon,
  image: ImageIcon,
  brain: Brain,
  history: History,
  moon: MoonStar,
  heart: HeartPulse,
  trophy: Trophy,
};

export const AVATARS: { id: string; label: string; icon: LucideIcon }[] = [
  { id: 'graduation', label: 'الأكاديمي', icon: GraduationCap },
  { id: 'user', label: 'الباحث', icon: User },
  { id: 'book', label: 'القارئ', icon: BookOpen },
  { id: 'rocket', label: 'المستكشف', icon: Rocket },
  { id: 'crown', label: 'البطل', icon: Crown },
  { id: 'star', label: 'النجم', icon: Star },
  { id: 'bulb', label: 'المفكر', icon: Lightbulb },
  { id: 'cat', label: 'الفضولي', icon: Cat },
];

export function avatarIcon(id: string): LucideIcon {
  return AVATARS.find((a) => a.id === id)?.icon ?? User;
}

export function Avatar({ id, size = 44 }: { id: string; size?: number }) {
  const Icon = avatarIcon(id);
  return (
    <div
      className="rounded-full bg-gradient-to-br from-gold-300 to-gold-600 flex items-center justify-center shrink-0 shadow-lg shadow-gold-600/20"
      style={{ width: size, height: size }}
    >
      <Icon style={{ width: size * 0.52, height: size * 0.52 }} className="text-navy-900" strokeWidth={2.2} />
    </div>
  );
}

export function DifficultyStars({ level, size = 13 }: { level: number; size?: number }) {
  return (
    <span className="inline-flex items-center gap-0.5" title={`الصعوبة ${level} من 3`}>
      {[1, 2, 3].map((i) => (
        <Star key={i} style={{ width: size, height: size }} className={i <= level ? 'text-gold-400 fill-gold-400' : 'text-white/25'} />
      ))}
    </span>
  );
}

export function ProgressBar({ pct, className = '' }: { pct: number; className?: string }) {
  return (
    <div className={`h-2 rounded-full bg-white/10 overflow-hidden ${className}`}>
      <div
        className="h-full rounded-full bg-gradient-to-l from-gold-300 to-gold-600 transition-all duration-700"
        style={{ width: `${Math.max(0, Math.min(100, pct))}%` }}
      />
    </div>
  );
}

export function SectionHeader({ title, sub, action }: { title: string; sub?: string; action?: ReactNode }) {
  return (
    <div className="flex items-end justify-between mb-3">
      <div>
        <h2 className="text-lg font-bold text-white flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-gold-400" />
          {title}
        </h2>
        {sub && <p className="text-xs text-slate-400 mt-0.5">{sub}</p>}
      </div>
      {action}
    </div>
  );
}

export function PageTop({ title, sub, onBack }: { title: string; sub?: string; onBack: () => void }) {
  return (
    <div className="flex items-center gap-3 mb-5 anim-fade-up">
      <button
        onClick={onBack}
        className="w-10 h-10 rounded-xl glass flex items-center justify-center text-gold-300 active:scale-95 transition"
        aria-label="رجوع"
      >
        <ChevronRight className="w-5 h-5" />
      </button>
      <div>
        <h1 className="text-xl font-bold text-white leading-tight">{title}</h1>
        {sub && <p className="text-xs text-slate-400">{sub}</p>}
      </div>
    </div>
  );
}

export function Toggle({ on, onChange, label }: { on: boolean; onChange: (v: boolean) => void; label: string }) {
  return (
    <button onClick={() => onChange(!on)} className="flex items-center justify-between w-full py-1" aria-pressed={on}>
      <span className="text-sm text-slate-200">{label}</span>
      <span className={`w-12 h-7 rounded-full p-1 transition-colors ${on ? 'bg-gold-500' : 'bg-white/15'}`}>
        <span className={`block w-5 h-5 rounded-full bg-white shadow transition-transform ${on ? '-translate-x-5' : 'translate-x-0'}`} />
      </span>
    </button>
  );
}

export function Modal({ open, onClose, children }: { open: boolean; onClose: () => void; children: ReactNode }) {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-4 bg-navy-950/80 backdrop-blur-sm" onClick={onClose}>
      <div
        className="w-full max-w-md rounded-3xl bg-navy-800 border border-gold-500/25 p-5 anim-pop shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex justify-end -mt-1 -ms-1 mb-1">
          <button onClick={onClose} className="w-8 h-8 rounded-lg bg-white/5 flex items-center justify-center text-slate-300" aria-label="إغلاق">
            <X className="w-4 h-4" />
          </button>
        </div>
        {children}
      </div>
    </div>
  );
}

// «معرفة المزيد حول الإجابة»: معلومات موسّعة مكتوبة داخل التطبيق + زر بحث خارجي في ويكيبيديا العربية
export function LearnMore({ q }: { q: Question }) {
  const [open, setOpen] = useState(false);
  const topic = (q.topic ?? q.correctText ?? '').trim();
  const numericOnly = /^[\d\s.,%٪+-]+$/.test(topic);
  const wikiUrl = topic && !numericOnly
    ? `https://ar.wikipedia.org/w/index.php?search=${encodeURIComponent(topic)}`
    : null;

  return (
    <div className="mt-3">
      <button
        onClick={() => setOpen((o) => !o)}
        className="w-full flex items-center gap-2 rounded-xl bg-gold-500/10 border border-gold-500/30 px-3.5 py-2.5 text-[13px] font-bold text-gold-200 active:scale-[0.99] transition"
        aria-expanded={open}
      >
        <BookMarked className="w-4 h-4 text-gold-400 shrink-0" />
        <span className="flex-1 text-start">معرفة المزيد حول هذه الإجابة</span>
        <ChevronDown className={`w-4 h-4 shrink-0 transition-transform ${open ? 'rotate-180' : ''}`} />
      </button>
      {open && (
        <div className="mt-2 rounded-xl bg-navy-900/60 border border-white/10 px-3.5 py-3 anim-fade-up">
          {q.more ? (
            <p className="text-[13px] text-slate-200 leading-relaxed">{q.more}</p>
          ) : q.type === 'mcq' || q.type === 'image' ? (
            <p className="text-[13px] text-slate-300 leading-relaxed">
              لتعميق فهمك لموضوع الإجابة «<b className="text-gold-300">{q.correctText}</b>» يمكنك قراءة المقالات المرتبطة بها عبر البحث الخارجي بالأسفل.
            </p>
          ) : (
            <p className="text-[13px] text-slate-300 leading-relaxed">
              راجع خطوات الحل والتفسير أعلاه لتثبيت المعلومة، ويمكنك تصفح أسئلة مشابهة من قسم «البحث في بنك الأسئلة».
            </p>
          )}
          {q.source && <p className="text-[11px] text-slate-500 mt-2">المصدر: {q.source}</p>}
          {wikiUrl && (
            <a
              href={wikiUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="mt-2.5 flex items-center justify-center gap-2 rounded-lg bg-white/5 border border-white/10 px-3 py-2.5 text-[12px] font-bold text-sky-300 active:scale-[0.99] transition"
            >
              <ExternalLink className="w-4 h-4 shrink-0" />
              اقرأ المزيد عن «{topic}» في ويكيبيديا العربية
            </a>
          )}
          {wikiUrl && <p className="text-[10px] text-slate-500 mt-1.5 text-center">رابط خارجي يفتح في المتصفح ويحتاج اتصالًا بالإنترنت</p>}
        </div>
      )}
    </div>
  );
}

export function EmptyState({ icon: Icon, title, desc }: { icon: LucideIcon; title: string; desc: string }) {
  return (
    <div className="glass rounded-3xl p-8 text-center">
      <div className="w-14 h-14 mx-auto rounded-2xl bg-gold-500/15 flex items-center justify-center mb-3">
        <Icon className="w-7 h-7 text-gold-400" />
      </div>
      <h3 className="font-bold text-white mb-1">{title}</h3>
      <p className="text-sm text-slate-400 leading-relaxed">{desc}</p>
    </div>
  );
}
