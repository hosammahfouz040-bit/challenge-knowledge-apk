// خريطة عالم مبسطة تفاعلية (قارات قابلة للضغط) — بديل محلي يعمل دون أي اتصال بالشبكة
interface Props {
  selected?: string | null;
  correctId?: string | null;
  wrongId?: string | null;
  onSelect?: (continent: string) => void;
  disabled?: boolean;
  showLabels?: boolean;
}

const SHAPES: { id: string; name: string; d: string; lx: number; ly: number }[] = [
  { id: 'namerica', name: 'أمريكا الشمالية', d: 'M58,92 L120,52 L238,38 L292,58 L306,96 L268,128 L232,128 L214,168 L186,206 L158,196 L150,158 L104,150 L66,128 Z', lx: 175, ly: 115 },
  { id: 'samerica', name: 'أمريكا الجنوبية', d: 'M222,232 L282,214 L314,250 L306,318 L272,392 L240,398 L226,330 L212,272 Z', lx: 262, ly: 305 },
  { id: 'europe', name: 'أوروبا', d: 'M372,58 L428,42 L478,52 L486,92 L452,112 L458,132 L420,128 L402,104 L372,104 L360,78 Z', lx: 425, ly: 88 },
  { id: 'africa', name: 'إفريقيا', d: 'M380,158 L462,142 L512,178 L498,246 L512,268 L462,342 L416,348 L388,286 L366,214 Z', lx: 440, ly: 245 },
  { id: 'asia', name: 'آسيا', d: 'M486,58 L640,34 L736,52 L762,104 L716,132 L724,168 L668,196 L640,158 L596,168 L566,206 L540,158 L506,142 L486,106 Z', lx: 615, ly: 110 },
  { id: 'oceania', name: 'أوقيانيا', d: 'M642,268 L724,252 L764,282 L742,330 L668,338 L636,306 Z', lx: 700, ly: 298 },
];

export default function WorldMap({ selected, correctId, wrongId, onSelect, disabled, showLabels }: Props) {
  const fillFor = (id: string) => {
    if (correctId && id === correctId) return 'rgba(16,185,129,0.75)';
    if (wrongId && id === wrongId) return 'rgba(239,68,68,0.7)';
    if (selected && id === selected) return 'rgba(238,201,92,0.85)';
    return 'rgba(56,96,160,0.55)';
  };
  const textFor = (id: string) => (id === selected || id === correctId ? '#081426' : '#dbe7ff');

  return (
    <div className="rounded-2xl overflow-hidden border border-white/10 bg-gradient-to-b from-navy-800 to-navy-900">
      <svg viewBox="0 0 800 420" className="w-full h-auto block" role="group" aria-label="خريطة العالم التفاعلية">
        {/* شبكة إحداثيات خفيفة */}
        {[70, 140, 210, 280, 350].map((y) => (
          <line key={y} x1="0" y1={y} x2="800" y2={y} stroke="rgba(255,255,255,0.05)" strokeWidth="1" />
        ))}
        {[130, 260, 390, 520, 650].map((x) => (
          <line key={x} x1={x} y1="0" x2={x} y2="420" stroke="rgba(255,255,255,0.05)" strokeWidth="1" />
        ))}
        {/* خط الاستواء */}
        <line x1="0" y1="228" x2="800" y2="228" stroke="rgba(238,201,92,0.18)" strokeWidth="1.4" strokeDasharray="6 6" />
        {SHAPES.map((s) => (
          <g key={s.id}>
            <path
              d={s.d}
              fill={fillFor(s.id)}
              stroke={selected === s.id || correctId === s.id ? '#eec95c' : 'rgba(219,231,255,0.45)'}
              strokeWidth={selected === s.id || correctId === s.id ? 2.4 : 1.2}
              className={disabled ? '' : 'cursor-pointer transition-all duration-200 hover:brightness-150'}
              onClick={() => !disabled && onSelect?.(s.id)}
            >
              <title>{s.name}</title>
            </path>
            {(showLabels || selected === s.id || correctId === s.id || wrongId === s.id) && (
              <text x={s.lx} y={s.ly} textAnchor="middle" fontSize="15" fontWeight="700" fill={textFor(s.id)} pointerEvents="none" style={{ fontFamily: 'inherit' }}>
                {s.name}
              </text>
            )}
          </g>
        ))}
      </svg>
    </div>
  );
}
