import { Lock } from 'lucide-react';
import { useApp } from '../lib/context';
import { ACHIEVEMENTS } from '../data/achievements';
import { PageTop, ProgressBar } from '../components/ui';

export default function Achievements() {
  const { state, go } = useApp();
  const unlockedCount = state.achievements.length;

  return (
    <div>
      <PageTop title="الشارات والإنجازات" sub={`فتحت ${unlockedCount} من ${ACHIEVEMENTS.length} شارة`} onBack={() => go({ name: 'home' })} />
      <div className="glass rounded-3xl p-4 mb-4">
        <div className="flex justify-between text-[12px] text-slate-300 mb-1.5">
          <span>تقدمك في جمع الشارات</span>
          <span className="text-gold-300 font-bold">{Math.round((unlockedCount / ACHIEVEMENTS.length) * 100)}%</span>
        </div>
        <ProgressBar pct={(unlockedCount / ACHIEVEMENTS.length) * 100} />
      </div>

      <div className="grid grid-cols-2 gap-3 stagger">
        {ACHIEVEMENTS.map((a) => {
          const unlocked = state.achievements.includes(a.id);
          const val = Math.min(a.value(state), a.target);
          return (
            <div key={a.id} className={`rounded-3xl p-4 border ${unlocked ? 'bg-gold-500/10 border-gold-400/40' : 'glass opacity-90'}`}>
              <div className={`w-12 h-12 rounded-2xl flex items-center justify-center mb-2.5 ${unlocked ? 'bg-gradient-to-br from-gold-300 to-gold-600 shadow-lg shadow-gold-600/25' : 'bg-white/5 border border-white/10'}`}>
                {unlocked ? <a.icon className="w-6 h-6 text-navy-900" /> : <Lock className="w-5 h-5 text-slate-500" />}
              </div>
              <h3 className={`font-bold text-[14px] ${unlocked ? 'text-gold-200' : 'text-slate-200'}`}>{a.title}</h3>
              <p className="text-[11px] text-slate-400 leading-relaxed mt-0.5 min-h-[30px]">{a.desc}</p>
              {unlocked ? (
                <span className="inline-block text-[10px] font-bold bg-gold-500 text-navy-900 rounded-full px-2 py-0.5 mt-1">تم فتحها</span>
              ) : (
                <div className="mt-2">
                  <div className="flex justify-between text-[10px] text-slate-500 mb-1">
                    <span>التقدم</span>
                    <span>{val} / {a.target}</span>
                  </div>
                  <ProgressBar pct={(val / a.target) * 100} className="h-1.5" />
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
