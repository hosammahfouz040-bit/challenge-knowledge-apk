import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  X, Flame, Heart, Scissors, Lightbulb, SkipForward, CheckCircle2, XCircle, Clock,
  ChevronLeft, BookOpen, Timer, ListOrdered, Map as MapIcon, Image as ImageIcon, Flag, RotateCcw,
} from 'lucide-react';
import { useApp } from '../lib/context';
import type { Session } from '../lib/game';
import { modeLabel, secondsPerQuestion } from '../lib/game';
import { categoryName, CONTINENTS } from '../data';
import { DifficultyStars, Modal, LearnMore } from '../components/ui';
import WorldMap from '../components/WorldMap';
import { sfx } from '../lib/audio';
import { clamp } from '../lib/utils';
import type { AnswerRecord, Question } from '../types';
import type { GameResult } from '../lib/progress';

const LETTERS = ['أ', 'ب', 'ج', 'د'];

export default function Quiz({ session, onExit }: { session: Session; onExit: () => void }) {
  const { state, completeGame } = useApp();
  const { config, items } = session;
  const mode = config.mode;
  const spq = secondsPerQuestion(mode);
  const sound = state.settings.sound;

  const [idx, setIdx] = useState(0);
  const [phase, setPhase] = useState<'answering' | 'feedback'>('answering');
  const [score, setScore] = useState(0);
  const [streak, setStreak] = useState(0);
  const [lives, setLives] = useState(3);
  const [records, setRecords] = useState<AnswerRecord[]>([]);
  const [selected, setSelected] = useState<number | null>(null);
  const [eliminated, setEliminated] = useState<Set<number>>(new Set());
  const [hintText, setHintText] = useState<string | null>(null);
  const [orderSel, setOrderSel] = useState<number[]>([]);
  const [mapSel, setMapSel] = useState<string | null>(null);
  const [timeLeft, setTimeLeft] = useState(spq);
  const [globalLeft, setGlobalLeft] = useState(60);
  const [exitOpen, setExitOpen] = useState(false);
  const [imgOk, setImgOk] = useState(true);
  const [lifelines, setLifelines] = useState({ fifty: 2, hint: 3, skip: 2 });

  const finishedRef = useRef(false);
  const stateRef = useRef({ score: 0, streak: 0, best: 0, lives: 3, records: [] as AnswerRecord[], skipped: 0 });
  const dq = items[Math.min(idx, items.length - 1)];
  const isLast = idx >= items.length - 1;
  const paused = exitOpen;

  const finish = useCallback(() => {
    if (finishedRef.current) return;
    finishedRef.current = true;
    if (sound) sfx.finish();
    const r = stateRef.current;
    const total = r.records.length;
    const correctCount = r.records.filter((x) => x.correct).length;
    const xpGain = correctCount * 5 + Math.floor(r.score / 10) + (total >= 5 && correctCount === total ? 20 : 0);
    const result: GameResult = {
      config,
      categoryLabel: mode === 'review' ? 'مراجعة الأخطاء' : mode === 'daily' ? 'التحدي اليومي' : config.category === 'all' ? 'كل الأقسام' : categoryName(config.category),
      score: r.score,
      xpGain,
      records: r.records,
      bestStreak: r.best,
      skipped: r.skipped,
    };
    completeGame(result);
  }, [completeGame, config, sound]);

  // ---- المؤقّتات ----
  useEffect(() => {
    setTimeLeft(spq);
  }, [idx, spq]);

  useEffect(() => {
    if (phase !== 'answering' || spq === 0 || paused || finishedRef.current) return;
    const iv = setInterval(() => setTimeLeft((t) => Math.max(0, +(t - 0.1).toFixed(2))), 100);
    return () => clearInterval(iv);
  }, [phase, idx, spq, paused]);

  useEffect(() => {
    if (mode !== 'quick' || paused || finishedRef.current) return;
    const iv = setInterval(() => setGlobalLeft((g) => Math.max(0, +(g - 0.1).toFixed(2))), 100);
    return () => clearInterval(iv);
  }, [mode, paused]);

  useEffect(() => {
    if (mode === 'quick' && globalLeft <= 0) finish();
  }, [globalLeft, mode, finish]);

  const ceilLeft = Math.ceil(timeLeft);
  useEffect(() => {
    if (sound && phase === 'answering' && spq > 0 && ceilLeft <= 5 && ceilLeft > 0) sfx.tick();
  }, [ceilLeft, phase, spq, sound]);

  // ---- منطق الإجابة ----
  const pointsFor = useCallback(
    (q: Question, isCorrect: boolean, newStreak: number) => {
      if (!isCorrect) return 0;
      let pts = q.difficulty * 10;
      if (q.type === 'order') pts = Math.round(pts * 1.5);
      if (spq > 0) pts += Math.round(10 * clamp(timeLeft / spq, 0, 1));
      else if (mode === 'quick') pts += 5;
      if (newStreak >= 3) pts += 5;
      return pts;
    },
    [mode, spq, timeLeft],
  );

  const registerAnswer = useCallback(
    (chosen: number | string | null, correct: boolean, timedOut = false) => {
      const newStreak = correct ? stateRef.current.streak + 1 : 0;
      const pts = pointsFor(dq.q, correct, newStreak);
      const chosenText =
        typeof chosen === 'number' ? dq.options[chosen] : typeof chosen === 'string' ? (CONTINENTS[chosen] ?? chosen) : 'انتهى الوقت دون إجابة';
      const rec: AnswerRecord = { question: dq.q, chosen, chosenText, correct, points: pts, timedOut };
      stateRef.current = {
        score: stateRef.current.score + pts,
        streak: newStreak,
        best: Math.max(stateRef.current.best, newStreak),
        lives: mode === 'survival' && !correct ? stateRef.current.lives - 1 : stateRef.current.lives,
        records: [...stateRef.current.records, rec],
        skipped: stateRef.current.skipped,
      };
      setScore(stateRef.current.score);
      setStreak(newStreak);
      setRecords(stateRef.current.records);
      if (mode === 'survival' && !correct) setLives(stateRef.current.lives);
      if (sound) (correct ? sfx.correct : sfx.wrong)();
      setPhase('feedback');
    },
    [dq, mode, pointsFor, sound],
  );

  const answerMcq = (i: number) => {
    if (phase !== 'answering' || eliminated.has(i)) return;
    setSelected(i);
    registerAnswer(i, i === dq.answerIdx);
  };

  const answerMap = (continent: string) => {
    if (phase !== 'answering') return;
    setMapSel(continent);
    registerAnswer(continent, continent === dq.q.continent);
  };

  const submitOrder = () => {
    if (phase !== 'answering' || orderSel.length !== dq.events.length) return;
    const chosenLabels = orderSel.map((i) => dq.events[i].label);
    const correctLabels = [...(dq.q.events ?? [])].sort((a, b) => a.year - b.year).map((e) => e.label);
    const correct = chosenLabels.every((l, i) => l === correctLabels[i]);
    registerAnswer(chosenLabels.join(' ← '), correct);
  };

  const onTimeout = useCallback(() => {
    if (phase !== 'answering' || finishedRef.current) return;
    if (dq.q.type === 'order') registerAnswer(null, false, true);
    else if (dq.q.type === 'map') registerAnswer(null, false, true);
    else registerAnswer(null, false, true);
  }, [phase, dq, registerAnswer]);

  useEffect(() => {
    if (spq > 0 && phase === 'answering' && timeLeft <= 0) onTimeout();
  }, [timeLeft, spq, phase, onTimeout]);

  const next = useCallback(() => {
    const dead = mode === 'survival' && stateRef.current.lives <= 0;
    if (isLast || dead || finishedRef.current) {
      finish();
      return;
    }
    setIdx((i) => i + 1);
    setPhase('answering');
    setSelected(null);
    setEliminated(new Set());
    setHintText(null);
    setOrderSel([]);
    setMapSel(null);
    setImgOk(true);
  }, [isLast, mode, finish]);

  // تقدّم تلقائي في التحدي السريع
  useEffect(() => {
    if (mode !== 'quick' || phase !== 'feedback') return;
    const t = setTimeout(next, 1000);
    return () => clearTimeout(t);
  }, [mode, phase, next]);

  // ---- وسائل المساعدة ----
  const useFifty = () => {
    if (phase !== 'answering' || lifelines.fifty <= 0 || (dq.q.type !== 'mcq' && dq.q.type !== 'image')) return;
    const wrongIdx = dq.options.map((_, i) => i).filter((i) => i !== dq.answerIdx && !eliminated.has(i));
    const shuffled = [...wrongIdx].sort(() => Math.random() - 0.5).slice(0, 2);
    setEliminated(new Set([...eliminated, ...shuffled]));
    setLifelines((l) => ({ ...l, fifty: l.fifty - 1 }));
    if (sound) sfx.lifeline();
  };

  const useHint = () => {
    if (phase !== 'answering' || lifelines.hint <= 0) return;
    const q = dq.q;
    if (q.type === 'order' && q.events) {
      const earliest = [...q.events].sort((a, b) => a.year - b.year)[0];
      setHintText(`تلميح: أقدم حدث في القائمة هو «${earliest.label}».`);
    } else if (q.type === 'map' && q.continent) {
      setHintText(`تلميح: اسم القارة الصحيحة يبدأ بحرف «${CONTINENTS[q.continent].charAt(0)}».`);
    } else {
      const ans = q.correctText.replace(/\s+/g, '');
      setHintText(`تلميح: تبدأ الإجابة الصحيحة بحرف «${ans.charAt(0)}» وتتكوّن من ${ans.length} حروف (دون مسافات).`);
    }
    setLifelines((l) => ({ ...l, hint: l.hint - 1 }));
    if (sound) sfx.lifeline();
  };

  const useSkip = () => {
    if (phase !== 'answering' || lifelines.skip <= 0) return;
    setLifelines((l) => ({ ...l, skip: l.skip - 1 }));
    stateRef.current = { ...stateRef.current, skipped: stateRef.current.skipped + 1 };
    if (sound) sfx.click();
    if (isLast) finish();
    else next();
  };

  const answeredCount = records.length;
  const timerPct = spq > 0 ? (timeLeft / spq) * 100 : 100;
  const correctSoFar = records.filter((r) => r.correct).length;

  const typeBadge = useMemo(() => {
    switch (dq.q.type) {
      case 'image': return { label: 'سؤال مصوّر', icon: ImageIcon };
      case 'order': return { label: 'ترتيب أحداث', icon: ListOrdered };
      case 'map': return { label: 'خريطة تفاعلية', icon: MapIcon };
      default: return null;
    }
  }, [dq]);

  if (!dq) return null;
  const lastRec = records[records.length - 1];
  const feedbackOk = phase === 'feedback' && lastRec?.correct;
  const feedbackTimeout = phase === 'feedback' && lastRec?.timedOut;

  return (
    <div className="anim-fade-up">
      {/* الشريط العلوي */}
      <div className="flex items-center gap-2 mb-3">
        <button onClick={() => setExitOpen(true)} className="w-9 h-9 rounded-xl glass flex items-center justify-center text-slate-300 active:scale-95" aria-label="إنهاء اللعبة">
          <X className="w-4.5 h-4.5" />
        </button>
        <span className="text-[11px] bg-navy-700 border border-white/10 rounded-full px-2.5 py-1 text-slate-200">{modeLabel(mode)}</span>
        <span className="text-[11px] bg-navy-700 border border-white/10 rounded-full px-2.5 py-1 text-slate-200 truncate">{categoryName(dq.q.category)}</span>
        <div className="flex-1" />
        {streak >= 2 && (
          <span className="flex items-center gap-1 text-orange-300 font-bold text-sm bg-orange-500/10 border border-orange-400/30 rounded-full px-2 py-1">
            <Flame className="w-4 h-4" /> {streak}
          </span>
        )}
        <span className="bg-gradient-to-l from-gold-400 to-gold-600 text-navy-900 font-bold rounded-full px-3 py-1 text-sm shadow">{score}</span>
      </div>

      {/* التقدم والمؤقت */}
      {mode === 'quick' ? (
        <div className="flex items-center gap-3 mb-3">
          <span className={`flex items-center gap-1 font-bold ${globalLeft <= 10 ? 'text-red-400 anim-danger' : 'text-gold-300'}`}>
            <Timer className="w-5 h-5" /> {Math.ceil(globalLeft)} ث
          </span>
          <div className="flex-1 h-2.5 rounded-full bg-white/10 overflow-hidden">
            <div className={`h-full rounded-full transition-all duration-100 ${globalLeft <= 10 ? 'bg-red-500' : 'bg-gradient-to-l from-gold-300 to-gold-600'}`} style={{ width: `${(globalLeft / 60) * 100}%` }} />
          </div>
          <span className="text-xs text-slate-300">أجبت {answeredCount} · صحيحة {correctSoFar}</span>
        </div>
      ) : mode === 'survival' ? (
        <div className="flex items-center gap-3 mb-3">
          <span className="flex items-center gap-1">
            {[1, 2, 3].map((h) => (
              <Heart key={h} className={`w-5 h-5 ${h <= lives ? 'text-red-500 fill-red-500' : 'text-white/20'}`} />
            ))}
          </span>
          <span className="text-xs text-slate-300">تجاوزت {answeredCount} سؤالًا · صحيحة {correctSoFar}</span>
          <div className="flex-1" />
          {spq > 0 && <span className="text-xs text-slate-400 flex items-center gap-1"><Clock className="w-3.5 h-3.5" /> {ceilLeft} ث</span>}
        </div>
      ) : (
        <div className="mb-3">
          <div className="flex justify-between text-[11px] text-slate-400 mb-1.5">
            <span>السؤال {Math.min(idx + 1, items.length)} من {items.length}</span>
            {spq > 0 && <span className={ceilLeft <= 5 && phase === 'answering' ? 'text-red-400 font-bold anim-danger' : ''}>المتبقي {ceilLeft} ثانية</span>}
          </div>
          <div className="h-2.5 rounded-full bg-white/10 overflow-hidden">
            <div className="h-full rounded-full bg-gradient-to-l from-sky-400 to-blue-600 transition-all duration-500" style={{ width: `${((idx + (phase === 'feedback' ? 1 : 0)) / items.length) * 100}%` }} />
          </div>
          {spq > 0 && (
            <div className="h-1.5 rounded-full bg-white/5 overflow-hidden mt-1.5">
              <div className={`h-full rounded-full transition-all duration-100 ${timerPct < 25 ? 'bg-red-500' : 'bg-gold-400/70'}`} style={{ width: `${timerPct}%` }} />
            </div>
          )}
        </div>
      )}

      {session.recycled && idx === 0 && phase === 'answering' && (
        <p className="text-[11px] text-amber-200/90 bg-amber-500/10 border border-amber-400/25 rounded-xl px-3 py-2 mb-3">
          نفدت الأسئلة الجديدة في هذا الاختيار، فأُعيد تدوير أسئلة لعبتها سابقًا لاستكمال الجولة — نقاطك ومستواك محفوظان دائمًا، ويمكنك جلب حزم جديدة من الملف الشخصي.
        </p>
      )}

      {/* بطاقة السؤال */}
      <section className="glass rounded-3xl p-4 mb-3 gold-border">
        <div className="flex items-center gap-2 mb-2 flex-wrap">
          {typeBadge && (
            <span className="flex items-center gap-1 text-[10px] bg-gold-500/15 text-gold-300 border border-gold-500/30 rounded-full px-2 py-0.5">
              <typeBadge.icon className="w-3 h-3" /> {typeBadge.label}
            </span>
          )}
          {dq.q.custom && <span className="text-[10px] bg-sky-500/15 text-sky-300 rounded-full px-2 py-0.5">من حزمك المستوردة</span>}
          {dq.q.generated && <span className="text-[10px] bg-violet-500/15 text-violet-300 rounded-full px-2 py-0.5">سؤال مولّد آليًا ومتحقق منه</span>}
          <span className="flex-1" />
          <DifficultyStars level={dq.q.difficulty} />
        </div>
        <h2 className="text-[17px] font-bold text-white leading-loose">{dq.q.text}</h2>

        {dq.q.type === 'image' && dq.q.image && imgOk && (
          <div className="mt-3 rounded-2xl overflow-hidden border border-white/10">
            <img src={dq.q.image} alt={dq.q.imageAlt ?? 'صورة السؤال'} className="w-full h-48 object-cover" loading="lazy" onError={() => setImgOk(false)} />
          </div>
        )}
        {dq.q.type === 'image' && !imgOk && (
          <p className="mt-3 text-[12px] text-slate-400 bg-white/5 rounded-xl px-3 py-2">تعذر تحميل الصورة (وضع عدم الاتصال) — أجب اعتمادًا على نص السؤال: {dq.q.imageAlt}</p>
        )}

        {hintText && phase === 'answering' && (
          <p className="mt-3 text-[13px] text-amber-100 bg-amber-500/10 border border-amber-400/30 rounded-xl px-3 py-2 flex items-start gap-2">
            <Lightbulb className="w-4 h-4 text-gold-400 shrink-0 mt-0.5" /> {hintText}
          </p>
        )}
      </section>

      {/* منطقة الإجابة */}
      {(dq.q.type === 'mcq' || dq.q.type === 'image') && (
        <div className="space-y-2.5 mb-3">
          {dq.options.map((opt, i) => {
            const isOut = eliminated.has(i);
            const isAnswer = i === dq.answerIdx;
            const isChosen = selected === i;
            let cls = 'glass text-slate-100 active:scale-[0.99]';
            if (phase === 'feedback') {
              if (isAnswer) cls = 'bg-emerald-500/20 border-emerald-400/70 text-emerald-100 border';
              else if (isChosen) cls = 'bg-red-500/20 border-red-400/70 text-red-100 border anim-shake';
              else cls = 'glass text-slate-400 opacity-60';
            } else if (isOut) cls = 'glass text-slate-500 opacity-40 line-through';
            return (
              <button
                key={i}
                disabled={phase === 'feedback' || isOut}
                onClick={() => answerMcq(i)}
                className={`w-full rounded-2xl px-4 py-3.5 flex items-center gap-3 text-start transition ${cls}`}
              >
                <span className={`w-8 h-8 rounded-lg flex items-center justify-center font-bold text-sm shrink-0 ${
                  phase === 'feedback' && isAnswer ? 'bg-emerald-500 text-white' : phase === 'feedback' && isChosen ? 'bg-red-500 text-white' : 'bg-navy-700 text-gold-300 border border-white/10'
                }`}>
                  {phase === 'feedback' && isAnswer ? <CheckCircle2 className="w-4.5 h-4.5" /> : phase === 'feedback' && isChosen ? <XCircle className="w-4.5 h-4.5" /> : LETTERS[i]}
                </span>
                <span className="font-medium text-[15px] leading-relaxed">{opt}</span>
              </button>
            );
          })}
        </div>
      )}

      {dq.q.type === 'map' && (
        <div className="mb-3">
          <WorldMap
            selected={mapSel}
            correctId={phase === 'feedback' ? dq.q.continent : null}
            wrongId={phase === 'feedback' && mapSel && mapSel !== dq.q.continent ? mapSel : null}
            onSelect={answerMap}
            disabled={phase === 'feedback'}
            showLabels={phase === 'feedback'}
          />
          {phase === 'answering' && <p className="text-[11px] text-slate-400 mt-2 text-center">اضغط على القارة التي تظن أن الدولة تقع فيها</p>}
        </div>
      )}

      {dq.q.type === 'order' && (
        <div className="mb-3">
          {phase === 'answering' ? (
            <>
              <div className="flex flex-wrap gap-2 mb-3 min-h-[42px] rounded-2xl border border-dashed border-gold-500/30 bg-navy-800/60 p-2">
                {orderSel.length === 0 && <span className="text-[12px] text-slate-500 px-2 py-1.5">اضغط الأحداث بالترتيب من الأقدم إلى الأحدث…</span>}
                {orderSel.map((ei, pos) => (
                  <span key={ei} className="flex items-center gap-1.5 bg-gold-500/15 border border-gold-400/40 text-gold-100 rounded-full px-2.5 py-1.5 text-[12px] font-bold">
                    <span className="w-5 h-5 rounded-full bg-gold-500 text-navy-900 text-[11px] flex items-center justify-center">{pos + 1}</span>
                    {dq.events[ei].label}
                  </span>
                ))}
              </div>
              <div className="space-y-2">
                {dq.events.map((ev, i) => {
                  const used = orderSel.includes(i);
                  return (
                    <button
                      key={i}
                      disabled={used}
                      onClick={() => setOrderSel((s) => [...s, i])}
                      className={`w-full rounded-2xl px-4 py-3 text-start text-[14px] font-medium transition ${used ? 'glass opacity-35' : 'glass text-slate-100 active:scale-[0.99]'}`}
                    >
                      {ev.label}
                    </button>
                  );
                })}
              </div>
              <div className="flex gap-2 mt-3">
                <button
                  onClick={() => setOrderSel((s) => s.slice(0, -1))}
                  disabled={orderSel.length === 0}
                  className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl glass text-sm text-slate-200 disabled:opacity-40"
                >
                  <RotateCcw className="w-4 h-4" /> تراجع
                </button>
                <button
                  onClick={submitOrder}
                  disabled={orderSel.length !== dq.events.length}
                  className="flex-1 py-2.5 rounded-xl bg-gradient-to-l from-gold-400 to-gold-600 text-navy-900 font-bold text-sm disabled:opacity-40 active:scale-[0.98] transition"
                >
                  تأكيد الترتيب
                </button>
              </div>
            </>
          ) : (
            <div className="glass rounded-2xl p-3.5">
              <p className="text-[12px] text-slate-400 mb-2 font-bold">الترتيب الصحيح من الأقدم إلى الأحدث:</p>
              <ol className="space-y-1.5">
                {[...(dq.q.events ?? [])].sort((a, b) => a.year - b.year).map((ev, i) => (
                  <li key={i} className="flex items-center gap-2 text-[13px] text-slate-100">
                    <span className="w-5 h-5 rounded-full bg-emerald-500/80 text-white text-[11px] font-bold flex items-center justify-center shrink-0">{i + 1}</span>
                    {ev.label}
                    <span className="text-[11px] text-slate-500">({ev.year < 0 ? `${Math.abs(ev.year)} ق.م` : `${ev.year}م`})</span>
                  </li>
                ))}
              </ol>
            </div>
          )}
        </div>
      )}

      {/* وسائل المساعدة */}
      {phase === 'answering' && mode !== 'review' && (
        <div className="grid grid-cols-3 gap-2 mb-3">
          <button onClick={useFifty} disabled={lifelines.fifty <= 0 || (dq.q.type !== 'mcq' && dq.q.type !== 'image')} className="glass rounded-xl py-2.5 flex flex-col items-center gap-1 text-[11px] text-slate-200 disabled:opacity-35 active:scale-95 transition">
            <Scissors className="w-4.5 h-4.5 text-gold-400" /> حذف خيارين · {lifelines.fifty}
          </button>
          <button onClick={useHint} disabled={lifelines.hint <= 0 || !!hintText} className="glass rounded-xl py-2.5 flex flex-col items-center gap-1 text-[11px] text-slate-200 disabled:opacity-35 active:scale-95 transition">
            <Lightbulb className="w-4.5 h-4.5 text-gold-400" /> تلميح · {lifelines.hint}
          </button>
          <button onClick={useSkip} disabled={lifelines.skip <= 0} className="glass rounded-xl py-2.5 flex flex-col items-center gap-1 text-[11px] text-slate-200 disabled:opacity-35 active:scale-95 transition">
            <SkipForward className="w-4.5 h-4.5 text-gold-400" /> تجاوز · {lifelines.skip}
          </button>
        </div>
      )}

      {/* لوحة التفسير والتغذية الراجعة */}
      {phase === 'feedback' && lastRec && mode !== 'quick' && (
        <section className={`rounded-3xl p-4 border anim-pop ${feedbackOk ? 'bg-emerald-500/10 border-emerald-400/40' : 'bg-red-500/10 border-red-400/40'}`}>
          <div className="flex items-center gap-2 mb-1.5">
            {feedbackOk ? <CheckCircle2 className="w-5 h-5 text-emerald-400" /> : <XCircle className="w-5 h-5 text-red-400" />}
            <h3 className={`font-bold ${feedbackOk ? 'text-emerald-300' : 'text-red-300'}`}>
              {feedbackTimeout ? 'انتهى الوقت!' : feedbackOk ? `إجابة صحيحة! +${lastRec.points} نقطة` : 'إجابة غير صحيحة'}
            </h3>
          </div>
          {!feedbackOk && dq.q.type !== 'order' && (
            <p className="text-[13px] text-slate-200 mb-1">الإجابة الصحيحة: <b className="text-emerald-300">{dq.q.correctText}</b></p>
          )}
          <p className="text-[13px] text-slate-300 leading-relaxed flex gap-1.5">
            <BookOpen className="w-4 h-4 text-gold-400 shrink-0 mt-0.5" />
            <span>{dq.q.explanation}</span>
          </p>
          {dq.q.source && <p className="text-[11px] text-slate-500 mt-1.5">المصدر: {dq.q.source}</p>}
          <LearnMore key={dq.q.id} q={dq.q} />
          {mode === 'survival' && lives <= 0 && <p className="text-[12px] text-red-300 mt-2 font-bold">نفدت قلوبك الثلاثة — انتهت المغامرة!</p>}
          <button
            onClick={next}
            className="w-full mt-3 py-3 rounded-xl bg-gradient-to-l from-gold-400 to-gold-600 text-navy-900 font-bold flex items-center justify-center gap-1.5 active:scale-[0.98] transition"
          >
            {isLast || (mode === 'survival' && lives <= 0) ? (<><Flag className="w-4.5 h-4.5" /> عرض النتيجة</>) : (<>السؤال التالي <ChevronLeft className="w-4.5 h-4.5" /></>)}
          </button>
        </section>
      )}

      {phase === 'feedback' && mode === 'quick' && lastRec && (
        <div className={`rounded-2xl px-4 py-2.5 text-center font-bold text-sm anim-pop ${lastRec.correct ? 'bg-emerald-500/15 text-emerald-300' : 'bg-red-500/15 text-red-300'}`}>
          {lastRec.correct ? `صحيحة! +${lastRec.points}` : `الصحيحة: ${dq.q.correctText}`}
        </div>
      )}

      <Modal open={exitOpen} onClose={() => setExitOpen(false)}>
        <h3 className="font-bold text-white text-lg mb-1">إنهاء اللعبة؟</h3>
        <p className="text-sm text-slate-400 leading-relaxed mb-4">إذا خرجت الآن لن تُحتسب نتيجة هذه الجولة في نقاطك وسجلّك. أسئلة لعبتَها جزئيًا لا تُحفظ.</p>
        <div className="flex gap-2">
          <button onClick={() => setExitOpen(false)} className="flex-1 py-3 rounded-xl glass font-bold text-sm text-white">متابعة اللعب</button>
          <button onClick={onExit} className="flex-1 py-3 rounded-xl bg-red-500/80 font-bold text-sm text-white">إنهاء وخروج</button>
        </div>
      </Modal>
    </div>
  );
}
