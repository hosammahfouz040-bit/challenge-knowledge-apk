import { useRef, useState } from 'react';
import {
  Save, Volume2, Type, Gauge, Database, RefreshCw, Upload, Download, Trash2, Info,
  CheckCircle2, AlertTriangle, Loader2, ShieldCheck, Wand2, Link2,
} from 'lucide-react';
import { useApp } from '../lib/context';
import { AVATARS, Avatar, PageTop, ProgressBar, Toggle, Modal } from '../components/ui';
import { levelProgress, levelTitle, formatDateAr } from '../lib/utils';
import { BANK } from '../data';
import { defaultState, wipeState } from '../lib/store';
import { fetchRemotePack, validatePack } from '../lib/refresh';
import { generateMixedPack } from '../lib/gengeneral';
import type { Difficulty, Question } from '../types';

export default function Profile() {
  const { state, update, go, showToast } = useApp();
  const { profile, settings, stats } = state;
  const [name, setName] = useState(profile.name);
  const [status, setStatus] = useState<{ ok: boolean; msg: string } | null>(null);
  const [loading, setLoading] = useState(false);
  const [resetOpen, setResetOpen] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  const lp = levelProgress(profile.xp);
  const bankTotal = BANK.length + state.customQuestions.length;
  const usedCount = state.usedIds.length;

  const addQuestions = (qs: Question[], sourceLabel: string) => {
    if (qs.length === 0) return;
    update((s) => ({ ...s, customQuestions: [...s.customQuestions, ...qs] }));
    showToast(`أُضيف ${qs.length} سؤالًا جديدًا من ${sourceLabel} إلى بنكك المحلي`);
  };

  const onGenerate = () => {
    const exclude = new Set<string>([...BANK.map((x) => x.text), ...state.customQuestions.map((q) => q.text)]);
    const fresh = generateMixedPack(24, (Date.now() % 90000) + 11, exclude).map((q) => ({ ...q, custom: true }));
    addQuestions(fresh, 'التوليد البرمجي الشامل');
    setStatus({
      ok: fresh.length > 0,
      msg: fresh.length
        ? `وُلّد ${fresh.length} سؤالًا جديدًا موزعًا على أقسام التطبيق كلها بإجابات متحقق منها من جداول بيانات موثوقة داخل التطبيق، وحُفظت على جهازك لتعمل دون إنترنت.`
        : 'تعذر توليد أسئلة غير مكررة الآن، حاول مرة أخرى بعد قليل.',
    });
  };

  const onFetchRemote = async () => {
    setLoading(true);
    setStatus(null);
    const res = await fetchRemotePack(settings.remotePackUrl, state.customQuestions);
    setLoading(false);
    if (res.error) {
      setStatus({ ok: false, msg: res.error });
      return;
    }
    addQuestions(res.added, 'المصدر الخارجي');
    setStatus({
      ok: true,
      msg: res.added.length
        ? `تم التحقق وإضافة ${res.added.length} سؤالًا جديدًا${res.skipped ? ` وتجاوز ${res.skipped} سؤالًا مكررًا أو غير مكتمل` : ''}. حُفظت الأسئلة على جهازك وستعمل دون إنترنت.`
        : 'وصلت الحزمة لكن كل أسئلتها مكررة أو غير صالحة، فلم يُضف شيء. جرّب مصدرًا آخر.',
    });
  };

  const onImportFile = async (file: File) => {
    setStatus(null);
    try {
      const text = await file.text();
      const data: unknown = JSON.parse(text);
      const res = validatePack(data, state.customQuestions);
      if (res.error) {
        setStatus({ ok: false, msg: res.error });
        return;
      }
      addQuestions(res.added, 'الملف المستورد');
      setStatus({
        ok: res.added.length > 0,
        msg: res.added.length
          ? `استُورد ${res.added.length} سؤالًا بعد التحقق من صيغته وعدم تكراره${res.skipped ? ` (تُجاوز ${res.skipped})` : ''}.`
          : 'لم يُضف أي سؤال: كل عناصر الملف مكررة أو غير مطابقة للصيغة المطلوبة.',
      });
    } catch {
      setStatus({ ok: false, msg: 'الملف المختار ليس ملف JSON صالحًا.' });
    }
  };

  const onExport = () => {
    const blob = new Blob([JSON.stringify(state, null, 2)], { type: 'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'tahadi-alma3rifa-backup.json';
    a.click();
    URL.revokeObjectURL(a.href);
    showToast('تم تنزيل نسخة احتياطية من تقدمك وإعداداتك');
  };

  const onReset = () => {
    wipeState();
    update(() => structuredClone(defaultState));
    setResetOpen(false);
    go({ name: 'home' });
    showToast('تمت إعادة تعيين كل البيانات المحلية');
  };

  return (
    <div>
      <PageTop title="حسابي وإعداداتي" sub="ملفك المحلي محفوظ على جهازك فقط" onBack={() => go({ name: 'home' })} />

      {/* بطاقة اللاعب */}
      <section className="glass rounded-3xl p-4 mb-4 gold-border">
        <div className="flex items-center gap-3 mb-3">
          <Avatar id={profile.avatar} size={58} />
          <div className="flex-1 min-w-0">
            <p className="font-bold text-white text-lg truncate">{profile.name}</p>
            <p className="text-[12px] text-gold-300">المستوى {lp.level} · {levelTitle(lp.level)}</p>
            <p className="text-[11px] text-slate-500">عضو منذ {formatDateAr(profile.createdAt)}</p>
          </div>
          <div className="text-center shrink-0">
            <p className="font-black text-gold-300 text-xl">{profile.totalPoints.toLocaleString('en-US')}</p>
            <p className="text-[10px] text-slate-400">نقطة كلية</p>
          </div>
        </div>
        <div className="flex justify-between text-[11px] text-slate-400 mb-1">
          <span>الخبرة {profile.xp.toLocaleString('en-US')}</span>
          <span>{lp.current}/{lp.needed} للمستوى {lp.level + 1}</span>
        </div>
        <ProgressBar pct={lp.pct} />
        <div className="grid grid-cols-4 gap-2 mt-3 text-center">
          {[
            { v: stats.games, l: 'لعبة' },
            { v: stats.correct, l: 'إجابة صحيحة' },
            { v: state.achievements.length, l: 'شارة' },
            { v: stats.dailyDone, l: 'تحدٍّ يومي' },
          ].map((x) => (
            <div key={x.l} className="bg-white/5 rounded-xl py-2">
              <p className="font-bold text-white">{x.v}</p>
              <p className="text-[10px] text-slate-400">{x.l}</p>
            </div>
          ))}
        </div>
      </section>

      {/* تعديل الاسم والصورة */}
      <section className="glass rounded-3xl p-4 mb-4">
        <h3 className="font-bold text-white text-sm mb-3">الاسم والصورة الرمزية</h3>
        <div className="flex gap-2 mb-3">
          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            maxLength={24}
            placeholder="اسمك في التحدي"
            className="flex-1 bg-navy-800 border border-white/10 rounded-xl px-3.5 py-2.5 text-sm text-white outline-none focus:border-gold-400/60"
          />
          <button
            onClick={() => { update((s) => ({ ...s, profile: { ...s.profile, name: name.trim() || s.profile.name } })); showToast('تم حفظ الاسم'); }}
            className="px-4 rounded-xl bg-gradient-to-l from-gold-400 to-gold-600 text-navy-900 font-bold text-sm flex items-center gap-1.5 active:scale-95 transition"
          >
            <Save className="w-4 h-4" /> حفظ
          </button>
        </div>
        <div className="grid grid-cols-4 gap-2">
          {AVATARS.map((a) => (
            <button
              key={a.id}
              onClick={() => update((s) => ({ ...s, profile: { ...s.profile, avatar: a.id } }))}
              className={`rounded-2xl py-2.5 flex flex-col items-center gap-1 border transition ${profile.avatar === a.id ? 'bg-gold-500/15 border-gold-400/60' : 'glass border-transparent'}`}
            >
              <a.icon className={`w-5 h-5 ${profile.avatar === a.id ? 'text-gold-300' : 'text-slate-300'}`} />
              <span className="text-[10px] text-slate-300">{a.label}</span>
            </button>
          ))}
        </div>
      </section>

      {/* الإعدادات */}
      <section className="glass rounded-3xl p-4 mb-4">
        <h3 className="font-bold text-white text-sm mb-3">إعدادات العرض واللعب</h3>
        <div className="flex items-center gap-2 mb-2 text-[13px] text-slate-300"><Type className="w-4 h-4 text-gold-400" /> حجم الخط</div>
        <div className="grid grid-cols-3 gap-2 mb-4">
          {([['sm', 'صغير'], ['md', 'متوسط'], ['lg', 'كبير']] as const).map(([id, label]) => (
            <button
              key={id}
              onClick={() => update((s) => ({ ...s, settings: { ...s.settings, fontSize: id } }))}
              className={`py-2 rounded-xl text-sm font-bold ${settings.fontSize === id ? 'bg-gold-500/20 border border-gold-400/60 text-gold-200' : 'glass text-slate-300 border border-transparent'}`}
            >
              {label}
            </button>
          ))}
        </div>
        <div className="flex items-center gap-2 text-[13px] text-slate-300 mb-1"><Volume2 className="w-4 h-4 text-gold-400" /> المؤثرات الصوتية</div>
        <Toggle on={settings.sound} onChange={(v) => update((s) => ({ ...s, settings: { ...s.settings, sound: v } }))} label={settings.sound ? 'مفعّلة' : 'مكتومة'} />
        <div className="flex items-center gap-2 mt-4 mb-2 text-[13px] text-slate-300"><Gauge className="w-4 h-4 text-gold-400" /> الصعوبة الافتراضية عند إعداد لعبة</div>
        <div className="grid grid-cols-4 gap-2">
          {([0, 1, 2, 3] as (Difficulty | 0)[]).map((d) => (
            <button
              key={d}
              onClick={() => update((s) => ({ ...s, settings: { ...s.settings, difficulty: d } }))}
              className={`py-2 rounded-xl text-[13px] font-bold ${settings.difficulty === d ? 'bg-gold-500/20 border border-gold-400/60 text-gold-200' : 'glass text-slate-300 border border-transparent'}`}
            >
              {d === 0 ? 'مختلطة' : d === 1 ? 'سهلة' : d === 2 ? 'متوسطة' : 'صعبة'}
            </button>
          ))}
        </div>
      </section>

      {/* تجديد بنك الأسئلة */}
      <section className="glass rounded-3xl p-4 mb-4">
        <h3 className="font-bold text-white text-sm mb-1 flex items-center gap-2"><Database className="w-4 h-4 text-gold-400" /> بنك الأسئلة وتجديده</h3>
        <p className="text-[12px] text-slate-400 leading-relaxed mb-3">
          في البنك الآن <b className="text-gold-300">{bankTotal}</b> سؤالًا (منها {state.customQuestions.length} أضفتها أنت) · لعبت {usedCount} سؤالًا مختلفًا · يتبقى <b className="text-gold-300">{Math.max(0, bankTotal - usedCount)}</b> جديد. التجديد لا يمسّ نقاطك أو مستواك أبدًا.
        </p>

        <button onClick={onGenerate} className="w-full py-3 rounded-xl bg-violet-500/15 border border-violet-400/40 text-violet-200 font-bold text-sm flex items-center justify-center gap-2 mb-2.5 active:scale-[0.98] transition">
          <Wand2 className="w-4.5 h-4.5" /> توليد حزمة أسئلة جديدة شاملة (24 سؤالًا)
        </button>
        <p className="text-[11px] text-slate-500 leading-relaxed mb-3">يشمل التوليد البرمجي الآن أقسام التطبيق كلها: حسابات علمية ووحدات، عواصم ودول وأعلام، كواكب، سور قرآنية وأشهر هجرية وأنبياء، جموع وأضداد وكلمات عربية، فيتامينات ومؤشرات صحية، أبطال وكؤوس عالم، وألغاز ذكاء، وأسئلة ترتيب أحداث مولّدة من تواريخ موثقة — وكلها بإجابات تُبنى وتُتحقق برمجيًا فتكون صحيحة دائمًا. قسم الصور يُولّد فيه نصيًا أسئلة «الاكتشافات» فقط، لأن الصور الحقيقية لا تُولّد برمجيًا.</p>

        <label className="flex items-center gap-2 text-[13px] text-slate-300 mb-2"><Link2 className="w-4 h-4 text-gold-400" /> جلب حزمة أسئلة من رابط (JSON)</label>
        <input
          value={settings.remotePackUrl}
          onChange={(e) => update((s) => ({ ...s, settings: { ...s.settings, remotePackUrl: e.target.value } }))}
          placeholder="https://example.org/questions-pack.json"
          dir="ltr"
          className="w-full bg-navy-800 border border-white/10 rounded-xl px-3.5 py-2.5 text-[13px] text-white outline-none focus:border-gold-400/60 mb-2 text-left"
        />
        <div className="grid grid-cols-2 gap-2">
          <button onClick={onFetchRemote} disabled={loading} className="py-3 rounded-xl bg-gradient-to-l from-gold-400 to-gold-600 text-navy-900 font-bold text-sm flex items-center justify-center gap-2 disabled:opacity-50 active:scale-[0.98] transition">
            {loading ? <Loader2 className="w-4.5 h-4.5 animate-spin" /> : <RefreshCw className="w-4.5 h-4.5" />} جلب الحزمة
          </button>
          <button onClick={() => fileRef.current?.click()} className="py-3 rounded-xl glass font-bold text-sm text-white flex items-center justify-center gap-2 active:scale-[0.98] transition">
            <Upload className="w-4.5 h-4.5 text-gold-400" /> استيراد ملف JSON
          </button>
        </div>
        <input ref={fileRef} type="file" accept="application/json,.json" className="hidden" onChange={(e) => { const f = e.target.files?.[0]; if (f) void onImportFile(f); e.target.value = ''; }} />
        <p className="text-[11px] text-slate-500 leading-relaxed mt-2.5">
          صيغة الحزمة: قائمة عناصر لكل منها text وoptions (٤ خيارات) وanswer (رقم الخيار الصحيح من ٠) وexplanation اختياري. يتحقق التطبيق من اكتمال كل سؤال وعدم تكراره قبل إضافته. استخدم مصادر تملك حق نشر أسئلتها أو حزمًا أعددتها بنفسك.
        </p>
        {status && (
          <div className={`mt-3 rounded-xl px-3.5 py-2.5 text-[12px] leading-relaxed flex gap-2 ${status.ok ? 'bg-emerald-500/10 border border-emerald-400/30 text-emerald-200' : 'bg-red-500/10 border border-red-400/30 text-red-200'}`}>
            {status.ok ? <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5" /> : <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />}
            {status.msg}
          </div>
        )}
      </section>

      {/* البيانات والخصوصية */}
      <section className="glass rounded-3xl p-4 mb-4">
        <h3 className="font-bold text-white text-sm mb-3 flex items-center gap-2"><ShieldCheck className="w-4 h-4 text-gold-400" /> بياناتي وخصوصيتي</h3>
        <button onClick={onExport} className="w-full py-3 rounded-xl glass font-bold text-sm text-white flex items-center justify-center gap-2 mb-2 active:scale-[0.98] transition">
          <Download className="w-4.5 h-4.5 text-gold-400" /> تنزيل نسخة احتياطية من تقدمي
        </button>
        <button onClick={() => setResetOpen(true)} className="w-full py-3 rounded-xl bg-red-500/10 border border-red-400/30 text-red-200 font-bold text-sm flex items-center justify-center gap-2 active:scale-[0.98] transition">
          <Trash2 className="w-4.5 h-4.5" /> إعادة تعيين كل البيانات
        </button>
        <p className="text-[11px] text-slate-500 leading-relaxed mt-3 flex gap-1.5">
          <Info className="w-3.5 h-3.5 shrink-0 mt-0.5" />
          التطبيق لا يجمع أي بيانات شخصية ولا يطلب أي أذونات ولا يحتوي مفاتيح سرية؛ كل تقدمك وإعداداتك محفوظة في تخزين جهازك المحلي فقط.
        </p>
      </section>

      <section className="glass rounded-3xl p-4 mb-2">
        <h3 className="font-bold text-white text-sm mb-2">حول «تحدي المعرفة»</h3>
        <p className="text-[12px] text-slate-400 leading-relaxed">
          الإصدار 1.1 · تطبيق أسئلة عربي متكامل يعمل بالكامل دون إنترنت بعد تحميله: {BANK.length} سؤالًا مدمجًا في أحد عشر قسمًا: العلوم والثقافة والدين والحضارة الإسلامية والجغرافيا والتاريخ والفضاء وخريطة العالم والصور والألغاز وترتيب الأحداث والصحة والرياضة، مع زر «معرفة المزيد» داخل تفسير كل إجابة، إضافة إلى مولّد ألغاز رقمية وحزم قابلة للاستيراد. صُمم بواجهة عربية RTL بالأزرق الداكن والذهبي ليعمل بسلاسة على الهواتف الاقتصادية مثل Samsung Galaxy A04. تجهيز نسخة Android (APK) موثّق داخل ملفات المشروع (Capacitor + GitHub Actions).
        </p>
      </section>

      <Modal open={resetOpen} onClose={() => setResetOpen(false)}>
        <h3 className="font-bold text-white text-lg mb-1">إعادة تعيين كل شيء؟</h3>
        <p className="text-sm text-slate-400 leading-relaxed mb-4">سيُحذف ملفك ونقاطك ومستواك وشاراتك وسجلّك وأسئلتك المستوردة نهائيًا من هذا الجهاز. لا يمكن التراجع.</p>
        <div className="flex gap-2">
          <button onClick={() => setResetOpen(false)} className="flex-1 py-3 rounded-xl glass font-bold text-sm text-white">إلغاء</button>
          <button onClick={onReset} className="flex-1 py-3 rounded-xl bg-red-500 font-bold text-sm text-white">نعم، احذف الكل</button>
        </div>
      </Modal>
    </div>
  );
}
