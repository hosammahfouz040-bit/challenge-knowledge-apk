import { Play, Timer, Zap, HeartPulse, Shuffle, Lightbulb, CalendarCheck2, CheckCircle2, Flame, Star, ChevronLeft, BookOpenCheck, Database, Trophy, BarChart3 } from 'lucide-react';
import { useApp } from '../lib/context';
import { CATEGORIES, countOf } from '../data';
import { dailyFacts } from '../data/facts';
import { Avatar, CATEGORY_ICONS, ProgressBar, SectionHeader } from '../components/ui';
import { dayOfYear, levelProgress, levelTitle } from '../lib/utils';
import { BANK } from '../data';
import type { GameMode } from '../types';

export const MODES: { id: GameMode; name: string; desc: string; icon: typeof Play }[] = [
  { id: 'classic', name: 'اللعب الكلاسيكي', desc: 'أسئلة هادئة بـ 30 ثانية للسؤال', icon: Play },
  { id: 'timed', name: 'جولات محددة بالوقت', desc: '15 ثانية فقط لكل سؤال ونقاط إضافية للسرعة', icon: Timer },
  { id: 'quick', name: 'التحدي السريع', desc: '60 ثانية لأكبر عدد من الإجابات الصحيحة', icon: Zap },
  { id: 'survival', name: 'وضع البقاء', desc: 'ثلاثة قلوب فقط… كم تصمد؟', icon: HeartPulse },
  { id: 'mixed', name: 'الوضع المختلط', desc: 'أسئلة من كل الأقسام والمستويات', icon: Shuffle },
];

export default function Home() {
  const { state, go, startDaily } = useApp();
  const { profile, stats, daily, wrong } = state;
  const lp = levelProgress(profile.xp);
  const fact = dailyFacts[dayOfYear() % dailyFacts.length];
  const totalBank = BANK.length + state.customQuestions.length;
  const unused = totalBank - state.usedIds.filter((id) => !id.startsWith('gen-')).length;
  const hour = new Date().getHours();
  const greeting = hour < 12 ? 'صباح المعرفة' : hour < 18 ? 'نهارك سعيد' : 'مساء المعرفة';

  return (
    <div className="stagger">
      {/* رأس الصفحة */}
      <header className="flex items-center justify-between mb-5">
        <div className="flex items-center gap-3">
          <img src="/icon.png" alt="أيقونة تحدي المعرفة" className="w-12 h-12 rounded-2xl shadow-lg shadow-gold-600/25 border border-gold-500/40" />
          <div>
            <h1 className="text-xl font-bold gold-text leading-tight">تحدي المعرفة</h1>
            <p className="text-[11px] text-slate-400">اختبر ثقافتك… سؤالًا بعد سؤال</p>
          </div>
        </div>
        <button onClick={() => go({ name: 'profile' })} className="active:scale-95 transition" aria-label="الملف الشخصي">
          <Avatar id={profile.avatar} size={46} />
        </button>
      </header>

      {/* بطاقة اللاعب */}
      <section className="glass rounded-3xl p-4 mb-4 gold-border relative overflow-hidden">
        <div className="absolute -top-8 -start-8 w-32 h-32 rounded-full bg-gold-500/10 blur-2xl" />
        <div className="flex items-center gap-3 relative">
          <Avatar id={profile.avatar} size={54} />
          <div className="flex-1 min-w-0">
            <p className="text-xs text-slate-400">{greeting}،</p>
            <h2 className="font-bold text-white truncate">{profile.name}</h2>
            <p className="text-[11px] text-gold-300">المستوى {lp.level} · {levelTitle(lp.level)}</p>
          </div>
          <div className="text-center">
            <div className="flex items-center gap-1 text-gold-300 font-bold">
              <Star className="w-4 h-4 fill-gold-400 text-gold-400" />
              {profile.totalPoints.toLocaleString('en-US')}
            </div>
            <p className="text-[10px] text-slate-400">نقطة إجمالية</p>
          </div>
          <div className="text-center">
            <div className="flex items-center gap-1 text-orange-300 font-bold">
              <Flame className="w-4 h-4" />
              {stats.bestStreak}
            </div>
            <p className="text-[10px] text-slate-400">أفضل سلسلة</p>
          </div>
        </div>
        <div className="mt-3 relative">
          <div className="flex justify-between text-[11px] text-slate-400 mb-1">
            <span>نقاط الخبرة {profile.xp.toLocaleString('en-US')}</span>
            <span>{lp.current} / {lp.needed} للمستوى التالي</span>
          </div>
          <ProgressBar pct={lp.pct} />
        </div>
      </section>

      {/* معلومة اليوم */}
      <section className="rounded-3xl p-4 mb-4 bg-gradient-to-l from-navy-700/80 to-navy-800 border border-white/10 relative overflow-hidden">
        <div className="flex items-start gap-3">
          <div className="w-10 h-10 rounded-xl bg-gold-500/15 flex items-center justify-center shrink-0 anim-float">
            <Lightbulb className="w-5 h-5 text-gold-400" />
          </div>
          <div className="min-w-0">
            <h3 className="text-sm font-bold text-gold-300">معلومة اليوم: {fact.title}</h3>
            <p className="text-[13px] text-slate-200 leading-relaxed mt-1">{fact.body}</p>
            <p className="text-[11px] text-slate-500 mt-2">المصدر: {fact.source}</p>
          </div>
        </div>
      </section>

      {/* التحدي اليومي */}
      <section className="glass rounded-3xl p-4 mb-5">
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 rounded-2xl bg-gradient-to-br from-gold-400 to-gold-600 flex items-center justify-center shrink-0">
            {daily.completed ? <CheckCircle2 className="w-6 h-6 text-navy-900" /> : <CalendarCheck2 className="w-6 h-6 text-navy-900" />}
          </div>
          <div className="flex-1 min-w-0">
            <h3 className="font-bold text-white text-sm">التحدي اليومي</h3>
            <p className="text-[12px] text-slate-400">
              {daily.completed ? `أكملته اليوم بنتيجة ${daily.score} نقطة — عد غدًا لتحدٍّ جديد` : '10 أسئلة مختلطة تتجدد يوميًا + 30 نقطة خبرة إضافية'}
            </p>
          </div>
          {!daily.completed && (
            <button
              onClick={startDaily}
              className="px-4 py-2.5 rounded-xl bg-gradient-to-l from-gold-400 to-gold-600 text-navy-900 font-bold text-sm active:scale-95 transition shadow-lg shadow-gold-600/25"
            >
              ابدأ
            </button>
          )}
        </div>
      </section>

      {/* ابدأ اللعب */}
      <button
        onClick={() => go({ name: 'setup' })}
        className="w-full rounded-3xl bg-gradient-to-l from-gold-500 via-gold-400 to-gold-600 text-navy-900 font-bold text-lg py-4 mb-6 shadow-xl shadow-gold-600/25 active:scale-[0.98] transition flex items-center justify-center gap-2 anim-glow"
      >
        <Play className="w-6 h-6 fill-navy-900" />
        ابدأ تحديًا جديدًا
      </button>

      {/* أوضاع اللعب */}
      <SectionHeader title="أوضاع اللعب" sub="اختر أسلوبك المفضل" />
      <div className="flex gap-3 overflow-x-auto no-scrollbar pb-2 mb-5 -mx-1 px-1">
        {MODES.map((m) => (
          <button
            key={m.id}
            onClick={() => go({ name: 'setup', preset: { mode: m.id } })}
            className="glass card-hover rounded-2xl p-3 min-w-[132px] text-start"
          >
            <m.icon className="w-6 h-6 text-gold-400 mb-2" />
            <p className="font-bold text-[13px] text-white leading-snug">{m.name}</p>
            <p className="text-[11px] text-slate-400 leading-snug mt-1">{m.desc}</p>
          </button>
        ))}
      </div>

      {/* الأقسام */}
      <SectionHeader
        title="أقسام المعرفة"
        sub={`${totalBank} سؤالًا حقيقيًا في البنك · يتبقى ${Math.max(0, unused)} لم تلعبه بعد`}
        action={
          <button onClick={() => go({ name: 'categories' })} className="text-gold-300 text-xs flex items-center gap-0.5 shrink-0">
            التفاصيل <ChevronLeft className="w-3.5 h-3.5" />
          </button>
        }
      />
      <div className="grid grid-cols-2 gap-3 mb-5">
        {CATEGORIES.map((c) => {
          const Icon = CATEGORY_ICONS[c.icon];
          const total = countOf(c.id, state.customQuestions);
          return (
            <button
              key={c.id}
              onClick={() => go({ name: 'setup', preset: { category: c.id, mode: 'classic' } })}
              className="glass card-hover rounded-2xl p-3.5 text-start relative overflow-hidden"
            >
              <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${c.gradient} flex items-center justify-center mb-2 shadow-lg`}>
                <Icon className="w-5 h-5 text-white" />
              </div>
              <p className="font-bold text-[13px] text-white leading-snug">{c.name}</p>
              <p className="text-[11px] text-gold-300 mt-1 flex items-center gap-1">
                <Database className="w-3 h-3" /> {total} سؤالًا
                {c.special && <span className="text-[9px] bg-gold-500/20 text-gold-300 px-1.5 py-0.5 rounded-full">مميز</span>}
              </p>
            </button>
          );
        })}
      </div>

      {/* مراجعة الأخطاء */}
      {wrong.length > 0 && (
        <button onClick={() => go({ name: 'review' })} className="w-full glass card-hover rounded-3xl p-4 flex items-center gap-3 text-start mb-4">
          <div className="w-11 h-11 rounded-2xl bg-red-500/15 flex items-center justify-center shrink-0">
            <BookOpenCheck className="w-6 h-6 text-red-300" />
          </div>
          <div className="flex-1">
            <h3 className="font-bold text-white text-sm">راجع أخطاءك وتدرّب عليها</h3>
            <p className="text-[12px] text-slate-400">لديك {wrong.length} سؤالًا أخطأت فيه سابقًا بانتظار التصحيح</p>
          </div>
          <ChevronLeft className="w-5 h-5 text-slate-500" />
        </button>
      )}

      {/* إحصائيات وإنجازات */}
      <div className="grid grid-cols-2 gap-3">
        <button onClick={() => go({ name: 'stats' })} className="glass card-hover rounded-3xl p-4 text-start">
          <div className="w-10 h-10 rounded-2xl bg-sky-500/15 flex items-center justify-center mb-2">
            <BarChart3 className="w-5 h-5 text-sky-300" />
          </div>
          <h3 className="font-bold text-white text-sm">إحصائياتي وسجلّي</h3>
          <p className="text-[11px] text-slate-400 mt-0.5">دقتك {stats.answered ? Math.round((stats.correct / stats.answered) * 100) : 0}% · لعبت {stats.games} لعبة</p>
        </button>
        <button onClick={() => go({ name: 'achievements' })} className="glass card-hover rounded-3xl p-4 text-start">
          <div className="w-10 h-10 rounded-2xl bg-gold-500/15 flex items-center justify-center mb-2">
            <Trophy className="w-5 h-5 text-gold-400" />
          </div>
          <h3 className="font-bold text-white text-sm">شاراتي وإنجازاتي</h3>
          <p className="text-[11px] text-slate-400 mt-0.5">فتحت {state.achievements.length} شارة حتى الآن — واصل التقدم!</p>
        </button>
      </div>
    </div>
  );
}
