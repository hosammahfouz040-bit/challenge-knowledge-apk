import { useState } from 'react';
import { BookOpenCheck, Play, Trash2, ChevronDown } from 'lucide-react';
import { useApp } from '../lib/context';
import { categoryName } from '../data';
import { PageTop, EmptyState, Modal, DifficultyStars } from '../components/ui';

export default function Review() {
  const { state, update, go, startReview, showToast } = useApp();
  const [openId, setOpenId] = useState<string | null>(null);
  const [clearOpen, setClearOpen] = useState(false);
  const wrong = state.wrong;

  const removeOne = (id: string) => {
    update((s) => ({ ...s, wrong: s.wrong.filter((w) => w.id !== id) }));
    showToast('حُذف السؤال من قائمة المراجعة');
  };

  return (
    <div>
      <PageTop title="مراجعة الأخطاء" sub="تدرّب على ما أخطأت فيه حتى تتقنه" onBack={() => go({ name: 'home' })} />

      {wrong.length === 0 ? (
        <EmptyState
          icon={BookOpenCheck}
          title="قائمة المراجعة فارغة"
          desc="رائع! لا توجد أسئلة خاطئة بانتظارك الآن. كل سؤال تخطئ فيه أثناء اللعب سيظهر هنا تلقائيًا لتتدرب عليه لاحقًا."
        />
      ) : (
        <>
          <div className="glass rounded-3xl p-4 mb-4 flex items-center gap-3">
            <div className="flex-1">
              <p className="font-bold text-white text-sm">{wrong.length} سؤالًا بانتظار التصحيح</p>
              <p className="text-[12px] text-slate-400">التدريب بلا مؤقّت: أجب صحيحًا ليُحذف السؤال من القائمة. صححت حتى الآن {state.stats.reviewedCorrect} سؤالًا.</p>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-2.5 mb-4">
            <button onClick={startReview} className="py-3.5 rounded-2xl bg-gradient-to-l from-gold-400 to-gold-600 text-navy-900 font-bold flex items-center justify-center gap-2 active:scale-[0.98] transition">
              <Play className="w-5 h-5 fill-navy-900" /> بدء التدريب
            </button>
            <button onClick={() => setClearOpen(true)} className="py-3.5 rounded-2xl bg-red-500/10 border border-red-400/30 text-red-200 font-bold flex items-center justify-center gap-2 active:scale-[0.98] transition">
              <Trash2 className="w-4.5 h-4.5" /> مسح القائمة
            </button>
          </div>

          <div className="space-y-2">
            {wrong.map((q) => {
              const open = openId === q.id;
              return (
                <div key={q.id} className="glass rounded-2xl overflow-hidden">
                  <div className="flex items-start gap-2 px-3.5 py-3">
                    <button onClick={() => setOpenId(open ? null : q.id)} className="flex-1 text-start min-w-0">
                      <span className="flex items-center gap-2 mb-1">
                        <span className="text-[10px] bg-red-500/15 text-red-300 rounded-full px-2 py-0.5">{categoryName(q.category)}</span>
                        <DifficultyStars level={q.difficulty} size={11} />
                      </span>
                      <span className="block text-[13px] font-medium text-slate-100 leading-relaxed">{q.text}</span>
                    </button>
                    <button onClick={() => removeOne(q.id)} className="w-8 h-8 rounded-lg bg-white/5 flex items-center justify-center text-slate-400 shrink-0" aria-label="حذف من القائمة">
                      <Trash2 className="w-4 h-4" />
                    </button>
                    <ChevronDown className={`w-4 h-4 text-slate-500 shrink-0 mt-2 transition-transform ${open ? 'rotate-180' : ''}`} />
                  </div>
                  {open && (
                    <div className="px-3.5 pb-3.5 pt-2 border-t border-white/5 anim-fade-up">
                      <p className="text-[12px] text-emerald-300 font-bold">الإجابة الصحيحة: {q.correctText}</p>
                      <p className="text-[12px] text-slate-300 leading-relaxed mt-1">{q.explanation}</p>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </>
      )}

      <Modal open={clearOpen} onClose={() => setClearOpen(false)}>
        <h3 className="font-bold text-white text-lg mb-1">مسح قائمة المراجعة؟</h3>
        <p className="text-sm text-slate-400 leading-relaxed mb-4">ستُحذف كل الأسئلة الخاطئة المحفوظة ({wrong.length}) دون تدريب. الأسئلة التي تخطئ فيها مستقبلًا ستعود للقائمة.</p>
        <div className="flex gap-2">
          <button onClick={() => setClearOpen(false)} className="flex-1 py-3 rounded-xl glass font-bold text-sm text-white">إلغاء</button>
          <button onClick={() => { update((s) => ({ ...s, wrong: [] })); setClearOpen(false); showToast('تم مسح قائمة المراجعة'); }} className="flex-1 py-3 rounded-xl bg-red-500 font-bold text-sm text-white">مسح الكل</button>
        </div>
      </Modal>
    </div>
  );
}
