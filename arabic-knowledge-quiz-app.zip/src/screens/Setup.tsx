import { useMemo, useState } from 'react';
import { Play, Layers, Gauge, Hash, Info } from 'lucide-react';
import { useApp } from '../lib/context';
import { CATEGORIES } from '../data';
import { CATEGORY_ICONS, PageTop } from '../components/ui';
import { availableCount } from '../lib/game';
import { MODES } from './Home';
import type { CategoryId, Difficulty, GameConfig, GameMode } from '../types';

const DIFFS: { id: Difficulty | 0; name: string }[] = [
  { id: 0, name: 'مختلطة' },
  { id: 1, name: 'سهلة' },
  { id: 2, name: 'متوسطة' },
  { id: 3, name: 'صعبة' },
];

export default function Setup({ preset }: { preset?: Partial<GameConfig> }) {
  const { state, go, startGame } = useApp();
  const [mode, setMode] = useState<GameMode>(preset?.mode ?? 'classic');
  const [category, setCategory] = useState<CategoryId | 'all'>(preset?.category ?? 'all');
  const [difficulty, setDifficulty] = useState<Difficulty | 0>(preset?.difficulty ?? state.settings.difficulty);
  const [count, setCount] = useState<number>(preset?.count ?? 10);

  const config: GameConfig = useMemo(
    () => ({ mode, category: mode === 'mixed' ? category : category, difficulty, count }),
    [mode, category, difficulty, count],
  );
  const avail = useMemo(() => availableCount(config, state), [config, state]);
  const showCount = mode === 'classic' || mode === 'timed' || mode === 'mixed';
  const nothingAvailable = avail.total === 0;

  return (
    <div>
      <PageTop title="إعداد التحدي" sub="اختر الوضع والقسم ومستوى الصعوبة" onBack={() => go({ name: 'home' })} />

      <h3 className="font-bold text-white mb-2 flex items-center gap-2 text-sm"><Play className="w-4 h-4 text-gold-400" /> وضع اللعب</h3>
      <div className="grid grid-cols-2 gap-2.5 mb-5 stagger">
        {MODES.map((m) => (
          <button
            key={m.id}
            onClick={() => setMode(m.id)}
            className={`rounded-2xl p-3 text-start border transition active:scale-[0.98] ${
              mode === m.id ? 'bg-gold-500/15 border-gold-400/60' : 'glass border-white/10'
            }`}
          >
            <m.icon className={`w-5 h-5 mb-1.5 ${mode === m.id ? 'text-gold-300' : 'text-slate-300'}`} />
            <p className="font-bold text-[13px] text-white">{m.name}</p>
            <p className="text-[11px] text-slate-400 leading-snug mt-0.5">{m.desc}</p>
          </button>
        ))}
        <div className="rounded-2xl p-3 glass border-dashed flex items-start gap-2">
          <Info className="w-4 h-4 text-gold-400 shrink-0 mt-0.5" />
          <p className="text-[11px] text-slate-400 leading-relaxed">التحدي اليومي ومراجعة الأخطاء متاحان من الشاشة الرئيسية مباشرة.</p>
        </div>
      </div>

      <h3 className="font-bold text-white mb-2 flex items-center gap-2 text-sm"><Layers className="w-4 h-4 text-gold-400" /> القسم</h3>
      <div className="flex gap-2 overflow-x-auto no-scrollbar pb-2 mb-4 -mx-1 px-1">
        <button
          onClick={() => setCategory('all')}
          className={`px-4 py-2 rounded-full text-sm font-bold whitespace-nowrap transition ${
            category === 'all' ? 'bg-gradient-to-l from-gold-400 to-gold-600 text-navy-900' : 'glass text-slate-200'
          }`}
        >
          كل الأقسام
        </button>
        {CATEGORIES.map((c) => {
          const Icon = CATEGORY_ICONS[c.icon];
          return (
            <button
              key={c.id}
              onClick={() => setCategory(c.id)}
              className={`px-4 py-2 rounded-full text-sm font-bold whitespace-nowrap transition flex items-center gap-1.5 ${
                category === c.id ? 'bg-gradient-to-l from-gold-400 to-gold-600 text-navy-900' : 'glass text-slate-200'
              }`}
            >
              <Icon className="w-4 h-4" />
              {c.name}
            </button>
          );
        })}
      </div>

      <h3 className="font-bold text-white mb-2 flex items-center gap-2 text-sm"><Gauge className="w-4 h-4 text-gold-400" /> مستوى الصعوبة</h3>
      <div className="grid grid-cols-4 gap-2 mb-5">
        {DIFFS.map((d) => (
          <button
            key={String(d.id)}
            onClick={() => setDifficulty(d.id)}
            className={`py-2.5 rounded-xl text-sm font-bold transition ${
              difficulty === d.id ? 'bg-gold-500/20 border border-gold-400/60 text-gold-200' : 'glass text-slate-300 border border-transparent'
            }`}
          >
            {d.name}
          </button>
        ))}
      </div>

      {showCount && (
        <>
          <h3 className="font-bold text-white mb-2 flex items-center gap-2 text-sm"><Hash className="w-4 h-4 text-gold-400" /> عدد الأسئلة</h3>
          <div className="grid grid-cols-4 gap-2 mb-5">
            {[5, 10, 15, 20].map((n) => (
              <button
                key={n}
                onClick={() => setCount(n)}
                className={`py-2.5 rounded-xl text-sm font-bold transition ${
                  count === n ? 'bg-gold-500/20 border border-gold-400/60 text-gold-200' : 'glass text-slate-300 border border-transparent'
                }`}
              >
                {n}
              </button>
            ))}
          </div>
        </>
      )}

      <div className="glass rounded-2xl p-3.5 mb-5 text-[12px] leading-relaxed text-slate-300">
        {mode === 'quick' && <p>⏱ لديك 60 ثانية: كل إجابة صحيحة تضيف نقاطًا، والإجابة الخاطئة لا تخصم بل تنقلك للسؤال التالي.</p>}
        {mode === 'survival' && <p>❤ لديك 3 قلوب فقط: كل خطأ أو انتهاء وقت يفقدك قلبًا، واللعبة تنتهي بنفاد القلوب أو الأسئلة.</p>}
        {mode !== 'quick' && mode !== 'survival' && (
          <p>
            يتوفر في هذا الاختيار <b className="text-gold-300">{avail.total}</b> سؤالًا، منها <b className="text-gold-300">{avail.unused}</b> لم تلعبه بعد.
            {avail.unused < (showCount ? count : 10) && avail.total > 0 && ' سيعاد تدوير بعض الأسئلة لعبتها سابقًا لإكمال الجولة دون أن تفقد نقاطك أو مستواك أبدًا.'}
          </p>
        )}
        {nothingAvailable && <p className="text-red-300">لا توجد أسئلة مطابقة لهذا الاختيار (جرّب صعوبة مختلطة أو قسمًا آخر، أو جدّد البنك من الملف الشخصي).</p>}
      </div>

      <button
        disabled={nothingAvailable}
        onClick={() => startGame(config)}
        className="w-full rounded-2xl bg-gradient-to-l from-gold-500 via-gold-400 to-gold-600 text-navy-900 font-bold text-lg py-4 shadow-xl shadow-gold-600/25 active:scale-[0.98] transition disabled:opacity-40 disabled:shadow-none flex items-center justify-center gap-2"
      >
        <Play className="w-6 h-6 fill-navy-900" /> ابدأ اللعب الآن
      </button>
    </div>
  );
}
