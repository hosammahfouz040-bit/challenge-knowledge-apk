import { ChevronLeft, Database } from 'lucide-react';
import { useApp } from '../lib/context';
import { CATEGORIES, countOf } from '../data';
import { CATEGORY_ICONS, PageTop, ProgressBar } from '../components/ui';

export default function Categories() {
  const { state, go } = useApp();

  return (
    <div>
      <PageTop title="أقسام المعرفة" sub={`${CATEGORIES.length} قسمًا متنوعًا… اختر ساحة تحدّيك`} onBack={() => go({ name: 'home' })} />
      <div className="space-y-3 stagger">
        {CATEGORIES.map((c) => {
          const Icon = CATEGORY_ICONS[c.icon];
          const total = countOf(c.id, state.customQuestions);
          const cs = state.stats.perCategory[c.id];
          const acc = cs && cs.answered > 0 ? Math.round((cs.correct / cs.answered) * 100) : 0;
          return (
            <button
              key={c.id}
              onClick={() => go({ name: 'setup', preset: { category: c.id, mode: 'classic' } })}
              className="w-full glass card-hover rounded-3xl p-4 text-start"
            >
              <div className="flex items-center gap-3">
                <div className={`w-12 h-12 rounded-2xl bg-gradient-to-br ${c.gradient} flex items-center justify-center shrink-0 shadow-lg`}>
                  <Icon className="w-6 h-6 text-white" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <h3 className="font-bold text-white text-[15px]">{c.name}</h3>
                    {c.special && <span className="text-[9px] bg-gold-500/20 text-gold-300 px-1.5 py-0.5 rounded-full shrink-0">قسم مميز</span>}
                  </div>
                  <p className="text-[12px] text-slate-400">{c.desc}</p>
                  <p className="text-[11px] text-gold-300 mt-0.5 flex items-center gap-1">
                    <Database className="w-3 h-3" /> {total} سؤالًا في البنك
                  </p>
                </div>
                <ChevronLeft className="w-5 h-5 text-slate-500 shrink-0" />
              </div>
              {cs && cs.answered > 0 && (
                <div className="mt-3">
                  <div className="flex justify-between text-[11px] text-slate-400 mb-1">
                    <span>أجبت عن {cs.answered} سؤالًا · صحيحة {cs.correct}</span>
                    <span className="text-gold-300 font-bold">الدقة {acc}%</span>
                  </div>
                  <ProgressBar pct={acc} />
                </div>
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
}
