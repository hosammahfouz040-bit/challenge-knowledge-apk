import { useState } from 'react';
import { Trophy, Target, Flame, Star, Home, RotateCcw, BookOpenCheck, ChevronDown, CheckCircle2, XCircle, Sparkles, SkipForward } from 'lucide-react';
import { useApp } from '../lib/context';
import type { GameResult } from '../lib/progress';
import type { AchievementDef } from '../data/achievements';
import { LearnMore } from '../components/ui';
import { modeLabel } from '../lib/game';
import { categoryName } from '../data';
import { sfx } from '../lib/audio';

const CONFETTI_COLORS = ['#eec95c', '#38bdf8', '#f8fafc', '#34d399', '#f472b6'];

export default function Results({ result, unlocked, leveledUp, dailyBonus }: { result: GameResult; unlocked: AchievementDef[]; leveledUp: boolean; dailyBonus: number }) {
  const { state, go, startGame, startReview } = useApp();
  const [openIdx, setOpenIdx] = useState<number | null>(null);
  const total = result.records.length;
  const correct = result.records.filter((r) => r.correct).length;
  const acc = total ? Math.round((correct / total) * 100) : 0;
  const perfect = total >= 5 && correct === total;
  const celebrate = acc >= 70 && total >= 5;

  return (
    <div className="anim-fade-up relative">
      {celebrate && (
        <div className="fixed inset-0 pointer-events-none z-40 overflow-hidden">
          {Array.from({ length: 26 }).map((_, i) => (
            <span
              key={i}
              className="absolute top-0 rounded-sm"
              style={{
                left: `${(i * 37) % 100}%`,
                width: 7,
                height: 12,
                background: CONFETTI_COLORS[i % CONFETTI_COLORS.length],
                animation: `confettiFall ${2.2 + (i % 5) * 0.35}s ease-in ${(i % 7) * 0.18}s both`,
                transform: `rotate(${i * 47}deg)`,
              }}
            />
          ))}
        </div>
      )}

      <div className="text-center mb-5">
        <div className="w-20 h-20 mx-auto rounded-full bg-gradient-to-br from-gold-300 to-gold-600 flex items-center justify-center shadow-2xl shadow-gold-600/30 mb-3 anim-pop">
          <Trophy className="w-10 h-10 text-navy-900" />
        </div>
        <h1 className="text-2xl font-bold text-white">{perfect ? 'أداء مثالي أسطوري!' : acc >= 70 ? 'أحسنت يا بطل!' : acc >= 40 ? 'محاولة جيدة!' : 'لا بأس… واصل التدريب!'}</h1>
        <p className="text-sm text-slate-400">{modeLabel(result.config.mode)} · {result.categoryLabel}</p>
        <p className="text-5xl font-black gold-text mt-3">{result.score}</p>
        <p className="text-xs text-slate-400">نقطة</p>
      </div>

      <div className="grid grid-cols-4 gap-2 mb-4">
        {[
          { icon: Target, label: 'الصحيحة', value: `${correct}/${total}` },
          { icon: Sparkles, label: 'الدقة', value: `${acc}%` },
          { icon: Flame, label: 'أطول سلسلة', value: String(result.bestStreak) },
          { icon: Star, label: 'خبرة +', value: `+${result.xpGain}` },
        ].map((s) => (
          <div key={s.label} className="glass rounded-2xl p-2.5 text-center">
            <s.icon className="w-4.5 h-4.5 text-gold-400 mx-auto mb-1" />
            <p className="font-bold text-white text-sm">{s.value}</p>
            <p className="text-[10px] text-slate-400">{s.label}</p>
          </div>
        ))}
      </div>

      {result.skipped > 0 && (
        <p className="text-[12px] text-slate-400 flex items-center gap-1.5 mb-3 justify-center">
          <SkipForward className="w-3.5 h-3.5" /> تجاوزت {result.skipped} سؤالًا بوسائل المساعدة
        </p>
      )}
      {dailyBonus > 0 && (
        <div className="rounded-2xl bg-gold-500/15 border border-gold-400/40 px-4 py-2.5 text-center text-sm text-gold-200 font-bold mb-3 anim-pop">
          مكافأة التحدي اليومي: +{dailyBonus} نقطة خبرة إضافية
        </div>
      )}
      {leveledUp && (
        <div className="rounded-2xl bg-gradient-to-l from-gold-500/25 to-gold-600/10 border border-gold-400/50 px-4 py-3 text-center mb-3 anim-pop">
          <p className="font-bold text-gold-200">ترقية! وصلت إلى مستوى جديد — راجع ملفك الشخصي</p>
        </div>
      )}
      {unlocked.length > 0 && (
        <div className="glass rounded-3xl p-4 mb-4">
          <h3 className="font-bold text-gold-300 text-sm mb-2.5">شارات جديدة فتحتها!</h3>
          <div className="space-y-2">
            {unlocked.map((a) => (
              <div key={a.id} className="flex items-center gap-3 bg-gold-500/10 border border-gold-500/25 rounded-2xl px-3 py-2">
                <span className="w-9 h-9 rounded-xl bg-gradient-to-br from-gold-300 to-gold-600 flex items-center justify-center shrink-0">
                  <a.icon className="w-5 h-5 text-navy-900" />
                </span>
                <div>
                  <p className="font-bold text-white text-sm">{a.title}</p>
                  <p className="text-[11px] text-slate-400">{a.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="grid grid-cols-2 gap-2.5 mb-3">
        <button onClick={() => { if (state.settings.sound) sfx.click(); startGame(result.config); }} className="py-3.5 rounded-2xl bg-gradient-to-l from-gold-400 to-gold-600 text-navy-900 font-bold flex items-center justify-center gap-2 active:scale-[0.98] transition">
          <RotateCcw className="w-5 h-5" /> العب مجددًا
        </button>
        <button onClick={() => go({ name: 'home' })} className="py-3.5 rounded-2xl glass font-bold text-white flex items-center justify-center gap-2 active:scale-[0.98] transition">
          <Home className="w-5 h-5" /> الرئيسية
        </button>
      </div>
      {result.records.some((r) => !r.correct) && (
        <button onClick={startReview} className="w-full py-3 rounded-2xl bg-red-500/15 border border-red-400/40 text-red-200 font-bold flex items-center justify-center gap-2 mb-5 active:scale-[0.98] transition">
          <BookOpenCheck className="w-5 h-5" /> تدريب فوري على أسئلة هذه الجولة الخاطئة
        </button>
      )}

      <h3 className="font-bold text-white mb-2.5">مراجعة أسئلة الجولة</h3>
      <div className="space-y-2">
        {result.records.map((r, i) => {
          const open = openIdx === i;
          return (
            <div key={i} className="glass rounded-2xl overflow-hidden">
              <button onClick={() => setOpenIdx(open ? null : i)} className="w-full flex items-start gap-2.5 px-3.5 py-3 text-start">
                {r.correct ? <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" /> : <XCircle className="w-5 h-5 text-red-400 shrink-0 mt-0.5" />}
                <span className="flex-1 text-[13px] font-medium text-slate-100 leading-relaxed">{r.question.text}</span>
                <span className="text-[10px] bg-white/5 rounded-full px-2 py-0.5 text-slate-400 shrink-0 mt-0.5">{categoryName(r.question.category)}</span>
                <ChevronDown className={`w-4 h-4 text-slate-500 shrink-0 mt-1 transition-transform ${open ? 'rotate-180' : ''}`} />
              </button>
              {open && (
                <div className="px-3.5 pb-3.5 pt-1 border-t border-white/5 anim-fade-up">
                  <p className="text-[12px] text-slate-300">إجابتك: <span className={r.correct ? 'text-emerald-300 font-bold' : 'text-red-300 font-bold'}>{r.chosenText ?? '—'}</span></p>
                  {!r.correct && <p className="text-[12px] text-slate-300 mt-0.5">الصحيحة: <span className="text-emerald-300 font-bold">{r.question.correctText}</span></p>}
                  <p className="text-[12px] text-slate-400 leading-relaxed mt-1.5">{r.question.explanation}</p>
                  {r.question.source && <p className="text-[11px] text-slate-500 mt-1">المصدر: {r.question.source}</p>}
                  <LearnMore q={r.question} />
                </div>
              )}
            </div>
          );
        })}
      </div>
      {total === 0 && <p className="text-center text-slate-400 text-sm py-6">لم تُجب عن أي سؤال في هذه الجولة.</p>}
    </div>
  );
}
