import { useMemo, useState } from 'react';
import { Search as SearchIcon, ChevronDown, BookOpen, Eye } from 'lucide-react';
import { useApp } from '../lib/context';
import { BANK, CATEGORIES, categoryName } from '../data';
import { PageTop, DifficultyStars, EmptyState, LearnMore } from '../components/ui';
import type { CategoryId } from '../types';

export default function Search() {
  const { state, go } = useApp();
  const [query, setQuery] = useState('');
  const [cat, setCat] = useState<CategoryId | 'all'>('all');
  const [openId, setOpenId] = useState<string | null>(null);

  const all = useMemo(() => [...BANK, ...state.customQuestions], [state.customQuestions]);
  const results = useMemo(() => {
    const q = query.trim();
    let pool = cat === 'all' ? all : all.filter((x) => x.category === cat);
    if (q.length >= 2) {
      pool = pool.filter(
        (x) => x.text.includes(q) || x.correctText.includes(q) || x.options.some((o) => o.includes(q)) || x.explanation.includes(q),
      );
    }
    return pool.slice(0, 80);
  }, [all, query, cat]);

  return (
    <div>
      <PageTop title="البحث في بنك الأسئلة" sub="ابحث وتعلّم: اعرض الإجابة والتفسير دون لعب" onBack={() => go({ name: 'home' })} />

      <div className="relative mb-3">
        <SearchIcon className="w-5 h-5 text-gold-400 absolute start-3.5 top-1/2 -translate-y-1/2" />
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="اكتب كلمة من سؤال أو إجابة… (حرفان على الأقل)"
          className="w-full bg-navy-800 border border-white/10 rounded-2xl ps-11 pe-4 py-3.5 text-sm text-white outline-none focus:border-gold-400/60 placeholder:text-slate-500"
        />
      </div>

      <div className="flex gap-2 overflow-x-auto no-scrollbar pb-2 mb-3 -mx-1 px-1">
        <button onClick={() => setCat('all')} className={`px-3.5 py-1.5 rounded-full text-[12px] font-bold whitespace-nowrap ${cat === 'all' ? 'bg-gradient-to-l from-gold-400 to-gold-600 text-navy-900' : 'glass text-slate-200'}`}>
          الكل
        </button>
        {CATEGORIES.map((c) => (
          <button key={c.id} onClick={() => setCat(c.id)} className={`px-3.5 py-1.5 rounded-full text-[12px] font-bold whitespace-nowrap ${cat === c.id ? 'bg-gradient-to-l from-gold-400 to-gold-600 text-navy-900' : 'glass text-slate-200'}`}>
            {c.name}
          </button>
        ))}
      </div>

      <p className="text-[12px] text-slate-400 mb-3">
        {query.trim().length >= 2 ? `وجدنا ${results.length} نتيجة مطابقة` : `تصفح ${Math.min(results.length, 80)} سؤالًا — اكتب للبحث في ${all.length} سؤالًا`}
      </p>

      {results.length === 0 ? (
        <EmptyState icon={BookOpen} title="لا نتائج مطابقة" desc="جرّب كلمات أخرى أو قسمًا مختلفًا. كل أسئلة البنك متاحة للتصفح هنا مع إجاباتها وتفسيراتها." />
      ) : (
        <div className="space-y-2">
          {results.map((q) => {
            const open = openId === q.id;
            return (
              <div key={q.id} className="glass rounded-2xl overflow-hidden">
                <button onClick={() => setOpenId(open ? null : q.id)} className="w-full px-3.5 py-3 flex items-start gap-2.5 text-start">
                  <span className="flex-1 min-w-0">
                    <span className="flex items-center gap-2 mb-1">
                      <span className="text-[10px] bg-gold-500/15 text-gold-300 rounded-full px-2 py-0.5">{categoryName(q.category)}</span>
                      <DifficultyStars level={q.difficulty} size={11} />
                    </span>
                    <span className="block text-[13px] font-medium text-slate-100 leading-relaxed">{q.text}</span>
                  </span>
                  <ChevronDown className={`w-4 h-4 text-slate-500 shrink-0 mt-1 transition-transform ${open ? 'rotate-180' : ''}`} />
                </button>
                {open && (
                  <div className="px-3.5 pb-3.5 pt-2 border-t border-white/5 anim-fade-up">
                    <p className="text-[12px] text-emerald-300 font-bold flex items-center gap-1.5"><Eye className="w-3.5 h-3.5" /> الإجابة الصحيحة: {q.correctText}</p>
                    {q.options.length > 0 && <p className="text-[12px] text-slate-400 mt-1">الخيارات: {q.options.join(' · ')}</p>}
                    <p className="text-[12px] text-slate-300 leading-relaxed mt-1.5">{q.explanation}</p>
                    {q.source && <p className="text-[11px] text-slate-500 mt-1">المصدر: {q.source}</p>}
                    <LearnMore q={q} />
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
