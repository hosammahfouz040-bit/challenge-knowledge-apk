import { Gamepad2, Target, Trophy, Flame, Star, BookOpenCheck, ChevronLeft, BarChart3 } from 'lucide-react';
import { useApp } from '../lib/context';
import { CATEGORIES } from '../data';
import { CATEGORY_ICONS, PageTop, ProgressBar } from '../components/ui';
import { modeLabel } from '../lib/game';
import { levelProgress, timeAgoAr } from '../lib/utils';
import type { GameMode } from '../types';

export default function Stats() {
  const { state, go, startReview } = useApp();
  const { stats, profile, history, wrong } = state;
  const acc = stats.answered ? Math.round((stats.correct / stats.answered) * 100) : 0;
  const lp = levelProgress(profile.xp);

  const cards = [
    { icon: Gamepad2, label: 'الألعاب', value: stats.games },
    { icon: Target, label: 'الدقة العامة', value: `${acc}%` },
    { icon: Trophy, label: 'أفضل نتيجة', value: stats.bestScore },
    { icon: Flame, label: 'أفضل سلسلة', value: stats.bestStreak },
    { icon: Star, label: 'مجموع النقاط', value: profile.totalPoints.toLocaleString('en-US') },
    { icon: BarChart3, label: 'أسئلة مجابة', value: stats.answered },
  ];

  return (
    <div>
      <PageTop title="إحصائياتي" sub={`المستوى ${lp.level} · ${profile.xp.toLocaleString('en-US')} نقطة خبرة`} onBack={() => go({ name: 'home' })} />

      <div className="grid grid-cols-3 gap-2.5 mb-5 stagger">
        {cards.map((c) => (
          <div key={c.label} className="glass rounded-2xl p-3 text-center">
            <c.icon className="w-5 h-5 text-gold-400 mx-auto mb-1" />
            <p className="font-black text-white text-lg leading-none">{c.value}</p>
            <p className="text-[10px] text-slate-400 mt-1">{c.label}</p>
          </div>
        ))}
      </div>

      <h3 className="font-bold text-white mb-2.5">الأداء حسب القسم</h3>
      <div className="space-y-2.5 mb-5">
        {CATEGORIES.map((c) => {
          const Icon = CATEGORY_ICONS[c.icon];
          const cs = stats.perCategory[c.id];
          const pct = cs && cs.answered ? Math.round((cs.correct / cs.answered) * 100) : 0;
          return (
            <div key={c.id} className="glass rounded-2xl p-3">
              <div className="flex items-center gap-2 mb-1.5">
                <span className={`w-7 h-7 rounded-lg bg-gradient-to-br ${c.gradient} flex items-center justify-center shrink-0`}>
                  <Icon className="w-4 h-4 text-white" />
                </span>
                <span className="text-[13px] font-bold text-white flex-1 truncate">{c.name}</span>
                <span className="text-[11px] text-slate-400">{cs ? `${cs.correct}/${cs.answered} صحيحة` : 'لم تلعب بعد'}</span>
                <span className="text-[12px] font-bold text-gold-300 w-9 text-end">{cs ? `${pct}%` : '—'}</span>
              </div>
              <ProgressBar pct={pct} />
            </div>
          );
        })}
      </div>

      <h3 className="font-bold text-white mb-2.5">أفضل نتيجة في كل وضع</h3>
      <div className="glass rounded-3xl p-4 mb-5 space-y-2">
        {(['classic', 'timed', 'quick', 'survival', 'mixed', 'daily'] as GameMode[]).map((m) => (
          <div key={m} className="flex items-center justify-between text-sm">
            <span className="text-slate-300">{modeLabel(m)}</span>
            <span className="font-bold text-gold-300">{stats.bestByMode[m] ? `${stats.bestByMode[m]} نقطة` : '—'}</span>
          </div>
        ))}
      </div>

      {wrong.length > 0 && (
        <button onClick={startReview} className="w-full glass card-hover rounded-3xl p-4 flex items-center gap-3 text-start mb-5">
          <span className="w-11 h-11 rounded-2xl bg-red-500/15 flex items-center justify-center shrink-0">
            <BookOpenCheck className="w-6 h-6 text-red-300" />
          </span>
          <span className="flex-1">
            <span className="block font-bold text-white text-sm">أسئلة تحتاج مراجعة</span>
            <span className="block text-[12px] text-slate-400">{wrong.length} سؤالًا في قائمة أخطائك · صححت {stats.reviewedCorrect} منها</span>
          </span>
          <ChevronLeft className="w-5 h-5 text-slate-500" />
        </button>
      )}

      <h3 className="font-bold text-white mb-2.5">سجل النتائج الأخيرة</h3>
      {history.length === 0 ? (
        <div className="glass rounded-3xl p-6 text-center text-slate-400 text-sm">لا توجد ألعاب مسجلة بعد — ابدأ أول تحدٍّ لك!</div>
      ) : (
        <div className="space-y-2">
          {history.slice(0, 20).map((h) => (
            <div key={h.id} className="glass rounded-2xl px-3.5 py-3 flex items-center gap-3">
              <div className="flex-1 min-w-0">
                <p className="font-bold text-white text-[13px] truncate">{modeLabel(h.mode)} · {h.categoryLabel}</p>
                <p className="text-[11px] text-slate-500">{timeAgoAr(h.date)}</p>
              </div>
              <span className="text-[12px] text-slate-300">{h.correct}/{h.total} صحيحة</span>
              <span className="font-black text-gold-300">{h.score}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
