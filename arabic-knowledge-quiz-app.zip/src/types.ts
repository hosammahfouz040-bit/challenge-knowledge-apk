// الأنواع الأساسية لتطبيق «تحدي المعرفة»

export type CategoryId =
  | 'science'
  | 'culture'
  | 'religion'
  | 'geohist'
  | 'space'
  | 'worldmap'
  | 'images'
  | 'puzzles'
  | 'ordering'
  | 'health'
  | 'sports';

export type QType = 'mcq' | 'image' | 'order' | 'map';
export type Difficulty = 1 | 2 | 3;

export interface OrderEvent {
  label: string;
  year: number; // سنة ميلادية (سالب = قبل الميلاد)
}

export interface Question {
  id: string;
  category: CategoryId;
  type: QType;
  text: string;
  options: string[];
  answer: number; // فهرس الإجابة الصحيحة داخل options كما هي معروضة في بنك الأسئلة
  correctText: string;
  image?: string;
  imageAlt?: string;
  events?: OrderEvent[]; // لأسئلة الترتيب
  continent?: string; // لأسئلة الخريطة: القارة الصحيحة
  explanation: string;
  source?: string;
  more?: string; // معلومات موسّعة اختيارية تظهر في «معرفة المزيد حول الإجابة»
  topic?: string; // موضوع البحث الخارجي لتعميق المعرفة حول الإجابة
  difficulty: Difficulty;
  custom?: boolean;
  generated?: boolean;
}

// صيغة مختصرة لكتابة الأسئلة: [النص، الصحيحة، خطأ1، خطأ2، خطأ3، التفسير، الصعوبة؟، المصدر؟، معلومات إضافية؟]
export type RawQ = [string, string, string, string, string, string, Difficulty?, (string | undefined)?, string?];

export interface RawOrder {
  title: string;
  events: [string, number][];
  explanation: string;
  difficulty?: Difficulty;
  source?: string;
}

export type GameMode = 'classic' | 'timed' | 'quick' | 'survival' | 'mixed' | 'daily' | 'review';

export interface GameConfig {
  mode: GameMode;
  category: CategoryId | 'all';
  difficulty: Difficulty | 0; // 0 = مختلط
  count: number;
}

export interface AnswerRecord {
  question: Question;
  chosen: number | string | null; // فهرس الخيار، أو تسلسل الترتيب كنص، أو null عند انتهاء الوقت
  chosenText?: string; // نص ما اختاره اللاعب لعرضه في النتائج
  correct: boolean;
  points: number;
  timedOut?: boolean;
}

export interface Profile {
  name: string;
  avatar: string; // اسم أيقونة
  xp: number;
  totalPoints: number;
  createdAt: string;
}

export interface Settings {
  fontSize: 'sm' | 'md' | 'lg';
  sound: boolean;
  difficulty: Difficulty | 0;
  remotePackUrl: string;
}

export interface CategoryStat {
  answered: number;
  correct: number;
}

export interface Stats {
  games: number;
  answered: number;
  correct: number;
  bestStreak: number;
  bestScore: number;
  perfectGames: number;
  dailyDone: number;
  reviewedCorrect: number;
  bestSurvival: number;
  perCategory: Partial<Record<CategoryId, CategoryStat>>;
  bestByMode: Partial<Record<string, number>>;
}

export interface HistoryItem {
  id: string;
  date: string; // ISO
  mode: GameMode;
  categoryLabel: string;
  score: number;
  total: number;
  correct: number;
}

export interface DailyState {
  date: string; // YYYY-MM-DD
  completed: boolean;
  score: number;
}

export interface AppState {
  profile: Profile;
  settings: Settings;
  stats: Stats;
  history: HistoryItem[];
  wrong: Question[]; // لقطات كاملة للأسئلة الخاطئة للمراجعة
  usedIds: string[];
  achievements: string[];
  daily: DailyState;
  customQuestions: Question[];
  onboarded: boolean;
}
