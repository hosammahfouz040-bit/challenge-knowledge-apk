import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Home as HomeIcon, LayoutGrid, Search as SearchIcon, Trophy, User, Sparkles, CheckCircle2 } from 'lucide-react';
import { AppContext, type View } from './lib/context';
import { loadState, saveState } from './lib/store';
import { buildReviewSession, buildSession } from './lib/game';
import { applyGameResult, type GameResult } from './lib/progress';
import { sfx } from './lib/audio';
import type { AppState, GameConfig } from './types';
import Home from './screens/Home';
import Categories from './screens/Categories';
import Setup from './screens/Setup';
import Quiz from './screens/Quiz';
import Results from './screens/Results';
import Stats from './screens/Stats';
import Achievements from './screens/Achievements';
import Profile from './screens/Profile';
import Search from './screens/Search';
import Review from './screens/Review';
import { AVATARS } from './components/ui';

const FONT_SIZES = { sm: '15px', md: '16.5px', lg: '18.5px' } as const;

function Onboarding({ onDone }: { onDone: (name: string, avatar: string) => void }) {
  const [name, setName] = useState('');
  const [avatar, setAvatar] = useState('graduation');
  return (
    <div className="min-h-[80vh] flex flex-col justify-center anim-fade-up">
      <div className="text-center mb-6">
        <img src="/icon.png" alt="شعار تحدي المعرفة" className="w-24 h-24 rounded-[28px] mx-auto mb-4 shadow-2xl shadow-gold-600/30 border border-gold-500/40 anim-float" />
        <h1 className="text-3xl font-black gold-text mb-2">تحدي المعرفة</h1>
        <p className="text-slate-300 text-sm leading-relaxed max-w-xs mx-auto">
          أهلًا بك في ساحة الثقافة العربية: مئات الأسئلة الحقيقية، تحديات يومية، شارات ومستويات، وخريطة عالم تفاعلية — كل ذلك على جهازك ودون إنترنت.
        </p>
      </div>
      <div className="glass rounded-3xl p-5 gold-border">
        <label className="block text-sm font-bold text-white mb-2">ما اسمك يا بطل؟</label>
        <input
          value={name}
          onChange={(e) => setName(e.target.value)}
          maxLength={24}
          placeholder="اكتب اسمك هنا"
          className="w-full bg-navy-800 border border-white/10 rounded-xl px-4 py-3 text-white outline-none focus:border-gold-400/60 mb-4"
        />
        <label className="block text-sm font-bold text-white mb-2">اختر صورتك الرمزية</label>
        <div className="grid grid-cols-4 gap-2 mb-5">
          {AVATARS.map((a) => (
            <button
              key={a.id}
              onClick={() => setAvatar(a.id)}
              className={`rounded-2xl py-3 flex flex-col items-center gap-1 border transition ${avatar === a.id ? 'bg-gold-500/15 border-gold-400/60' : 'glass border-transparent'}`}
            >
              <a.icon className={`w-6 h-6 ${avatar === a.id ? 'text-gold-300' : 'text-slate-300'}`} />
              <span className="text-[10px] text-slate-300">{a.label}</span>
            </button>
          ))}
        </div>
        <button
          onClick={() => onDone(name.trim() || 'بطل المعرفة', avatar)}
          className="w-full py-4 rounded-2xl bg-gradient-to-l from-gold-500 via-gold-400 to-gold-600 text-navy-900 font-black text-lg shadow-xl shadow-gold-600/25 active:scale-[0.98] transition flex items-center justify-center gap-2"
        >
          <Sparkles className="w-5 h-5" /> ابدأ رحلة المعرفة
        </button>
      </div>
    </div>
  );
}

export default function App() {
  const [state, setState] = useState<AppState>(() => loadState());
  const [view, setView] = useState<View>({ name: 'home' });
  const [toast, setToast] = useState<string | null>(null);
  const toastTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    saveState(state);
  }, [state]);

  useEffect(() => {
    document.documentElement.style.fontSize = FONT_SIZES[state.settings.fontSize];
  }, [state.settings.fontSize]);

  useEffect(() => {
    window.scrollTo({ top: 0 });
  }, [view]);

  const showToast = useCallback((msg: string) => {
    setToast(msg);
    if (toastTimer.current) clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToast(null), 2800);
  }, []);

  const update = useCallback((fn: (s: AppState) => AppState) => setState(fn), []);
  const go = useCallback((v: View) => setView(v), []);

  const startGame = useCallback(
    (config: GameConfig) => {
      if (config.mode === 'review') {
        if (state.wrong.length === 0) {
          showToast('قائمة مراجعة الأخطاء فارغة حاليًا');
          return;
        }
        setView({ name: 'quiz', session: buildReviewSession(state.wrong) });
        return;
      }
      if (config.mode === 'daily' && state.daily.completed) {
        showToast('أكملت تحدي اليوم بالفعل — عد غدًا لتحدٍّ جديد!');
        return;
      }
      const session = buildSession(config, state);
      if (session.items.length === 0) {
        showToast('لا توجد أسئلة مطابقة لهذا الاختيار — غيّر القسم أو الصعوبة');
        return;
      }
      if (state.settings.sound) sfx.click();
      setView({ name: 'quiz', session });
    },
    [state, showToast],
  );

  const startDaily = useCallback(() => {
    startGame({ mode: 'daily', category: 'all', difficulty: 0, count: 10 });
  }, [startGame]);

  const startReview = useCallback(() => {
    if (state.wrong.length === 0) {
      showToast('لا توجد أسئلة خاطئة للتدريب الآن');
      return;
    }
    setView({ name: 'quiz', session: buildReviewSession(state.wrong) });
  }, [state.wrong, showToast]);

  const completeGame = useCallback(
    (result: GameResult) => {
      const outcome = applyGameResult(state, result);
      setState(outcome.next);
      if (outcome.unlocked.length > 0 && state.settings.sound) sfx.unlock();
      setView({ name: 'results', result, unlocked: outcome.unlocked, leveledUp: outcome.leveledUp, dailyBonus: outcome.dailyBonus });
    },
    [state],
  );

  const ctx = useMemo(
    () => ({ state, update, view, go, startGame, startDaily, startReview, completeGame, showToast }),
    [state, update, view, go, startGame, startDaily, startReview, completeGame, showToast],
  );

  const navItems = [
    { name: 'home' as const, label: 'الرئيسية', icon: HomeIcon, views: ['home', 'setup'] },
    { name: 'categories' as const, label: 'الأقسام', icon: LayoutGrid, views: ['categories'] },
    { name: 'search' as const, label: 'بحث', icon: SearchIcon, views: ['search'] },
    { name: 'achievements' as const, label: 'إنجازاتي', icon: Trophy, views: ['achievements'] },
    { name: 'profile' as const, label: 'حسابي', icon: User, views: ['profile', 'stats'] },
  ];
  const inGame = view.name === 'quiz';

  return (
    <AppContext.Provider value={ctx}>
      <div className="app-bg min-h-screen relative">
        <div className="relative z-10 max-w-md mx-auto px-4 pt-5 pb-28">
          {!state.onboarded ? (
            <Onboarding
              onDone={(name, avatar) => {
                update((s) => ({ ...s, onboarded: true, profile: { ...s.profile, name, avatar } }));
                showToast(`أهلًا بك يا ${name}! رحلة معرفة ممتعة`);
              }}
            />
          ) : (
            <>
              {view.name === 'home' && <Home />}
              {view.name === 'categories' && <Categories />}
              {view.name === 'setup' && <Setup key={JSON.stringify(view.preset ?? {})} preset={view.preset} />}
              {view.name === 'quiz' && <Quiz session={view.session} onExit={() => go({ name: 'home' })} />}
              {view.name === 'results' && <Results result={view.result} unlocked={view.unlocked} leveledUp={view.leveledUp} dailyBonus={view.dailyBonus} />}
              {view.name === 'stats' && <Stats />}
              {view.name === 'achievements' && <Achievements />}
              {view.name === 'profile' && <Profile />}
              {view.name === 'search' && <Search />}
              {view.name === 'review' && <Review />}
            </>
          )}
        </div>

        {state.onboarded && !inGame && (
          <nav className="fixed bottom-0 inset-x-0 z-40">
            <div className="max-w-md mx-auto px-3 pb-3">
              <div className="glass rounded-3xl shadow-2xl shadow-navy-950/60 flex justify-around py-2 px-1 border-white/10">
                {navItems.map((item) => {
                  const active = item.views.includes(view.name);
                  return (
                    <button
                      key={item.name}
                      onClick={() => go({ name: item.name } as View)}
                      className={`flex flex-col items-center gap-0.5 px-3 py-1.5 rounded-2xl transition active:scale-95 ${active ? 'text-gold-300' : 'text-slate-400'}`}
                    >
                      <item.icon className="w-5.5 h-5.5" />
                      <span className="text-[10px] font-bold">{item.label}</span>
                      {active && <span className="w-1 h-1 rounded-full bg-gold-400" />}
                    </button>
                  );
                })}
              </div>
            </div>
          </nav>
        )}

        {toast && (
          <div className="fixed bottom-24 inset-x-0 z-50 flex justify-center px-6 pointer-events-none">
            <div className="bg-navy-700 border border-gold-500/40 text-white text-sm font-bold rounded-2xl px-4 py-3 shadow-2xl flex items-center gap-2 anim-pop max-w-md text-center">
              <CheckCircle2 className="w-4.5 h-4.5 text-gold-400 shrink-0" />
              {toast}
            </div>
          </div>
        )}
      </div>
    </AppContext.Provider>
  );
}
