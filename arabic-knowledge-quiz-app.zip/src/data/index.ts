import type { CategoryId, Difficulty, Question, RawQ } from '../types';
import { hashString, mulberry32, shuffle } from '../lib/utils';
import scienceQuestions from './questions/science';
import cultureQuestions from './questions/culture';
import geohistQuestions from './questions/geohist';
import spaceQuestions from './questions/space';
import worldmapQuestions, { mapQuestions } from './questions/worldmap';
import { imageQuestions, discoveryQuestions } from './questions/images';
import puzzleQuestions from './questions/puzzles';
import orderingSets from './questions/ordering';
import { extraScience, extraCulture, extraGeohist, extraSpace, extraWorldmap, extraDiscovery } from './questions/extra';
import religionQuestions from './questions/religion';
import healthQuestions from './questions/health';
import sportsQuestions from './questions/sports';
import { enrichMore } from './enrich';

export interface CategoryMeta {
  id: CategoryId;
  name: string;
  desc: string;
  icon: string;
  gradient: string;
  special?: boolean;
}

export const CATEGORIES: CategoryMeta[] = [
  { id: 'science', name: 'العلوم والتكنولوجيا', desc: 'فيزياء وكيمياء وأحياء وحاسوب', icon: 'flask', gradient: 'from-sky-500 to-blue-700' },
  { id: 'culture', name: 'الثقافة والأدب واللغة العربية', desc: 'شعر وأدب ونحو وثقافة عامة', icon: 'book', gradient: 'from-amber-500 to-yellow-700' },
  { id: 'religion', name: 'الدين والحضارة الإسلامية', desc: 'قرآن كريم وسيرة نبوية وعبادات وعلماء المسلمين', icon: 'moon', gradient: 'from-teal-400 to-emerald-700', special: true },
  { id: 'geohist', name: 'الجغرافيا والتاريخ', desc: 'قارات وأنهار وحضارات وأحداث', icon: 'globe', gradient: 'from-emerald-500 to-teal-700' },
  { id: 'space', name: 'الفضاء والاختراعات', desc: 'كواكب ورواد ومخترعون عظام', icon: 'rocket', gradient: 'from-violet-500 to-purple-800' },
  { id: 'worldmap', name: 'تحدي خريطة العالم', desc: 'دول وعواصم وأعلام ومعالم', icon: 'map', gradient: 'from-cyan-500 to-sky-800', special: true },
  { id: 'images', name: 'عالم الصور والاكتشافات', desc: 'تعرّف على الصور واكتشافات غيّرت العالم', icon: 'image', gradient: 'from-pink-500 to-rose-700', special: true },
  { id: 'puzzles', name: 'ألغاز الذكاء والتفكير', desc: 'منطق وأنماط وحساب ذهني', icon: 'brain', gradient: 'from-orange-500 to-red-700', special: true },
  { id: 'ordering', name: 'ترتيب الأحداث التاريخية', desc: 'رتّب الأحداث من الأقدم للأحدث', icon: 'history', gradient: 'from-yellow-500 to-amber-800', special: true },
  { id: 'health', name: 'الصحة والغذاء', desc: 'جسم الإنسان وفيتامينات وإسعافات وطب', icon: 'heart', gradient: 'from-rose-400 to-red-600', special: true },
  { id: 'sports', name: 'الرياضة والأبطال', desc: 'كرة قدم وأولمبياد وأرقام قياسية وأبطال عرب', icon: 'trophy', gradient: 'from-indigo-500 to-blue-800', special: true },
];

export const categoryName = (id: CategoryId): string => CATEGORIES.find((c) => c.id === id)?.name ?? id;

export const CONTINENTS: Record<string, string> = {
  africa: 'إفريقيا',
  asia: 'آسيا',
  europe: 'أوروبا',
  namerica: 'أمريكا الشمالية',
  samerica: 'أمريكا الجنوبية',
  oceania: 'أوقيانيا',
};

function buildMcq(prefix: string, raw: RawQ[], category: CategoryId): Question[] {
  return raw.map((r, i) => {
    const [text, correct, w1, w2, w3, explanation, difficulty, source, moreRaw] = r;
    const id = `${prefix}-${i + 1}`;
    const options = shuffle([correct, w1, w2, w3], mulberry32(hashString(id + text)));
    return {
      id,
      category,
      type: 'mcq',
      text,
      options,
      answer: options.indexOf(correct),
      correctText: correct,
      explanation,
      source,
      more: moreRaw ?? enrichMore(text),
      topic: correct,
      difficulty: (difficulty ?? 1) as Difficulty,
    };
  });
}

function buildBank(): Question[] {
  const bank: Question[] = [
    ...buildMcq('sci', [...scienceQuestions, ...extraScience], 'science'),
    ...buildMcq('cul', [...cultureQuestions, ...extraCulture], 'culture'),
    ...buildMcq('geo', [...geohistQuestions, ...extraGeohist], 'geohist'),
    ...buildMcq('spc', [...spaceQuestions, ...extraSpace], 'space'),
    ...buildMcq('map', [...worldmapQuestions, ...extraWorldmap], 'worldmap'),
    ...buildMcq('dsc', [...discoveryQuestions, ...extraDiscovery], 'images'),
    ...buildMcq('puz', puzzleQuestions, 'puzzles'),
    ...buildMcq('rel', religionQuestions, 'religion'),
    ...buildMcq('hlt', healthQuestions, 'health'),
    ...buildMcq('spo', sportsQuestions, 'sports'),
  ];

  imageQuestions.forEach((im, i) => {
    const id = `img-${i + 1}`;
    const all = [im.correct, ...im.wrongs];
    const options = shuffle(all, mulberry32(hashString(id)));
    bank.push({
      id,
      category: 'images',
      type: 'image',
      text: im.text,
      options,
      answer: options.indexOf(im.correct),
      correctText: im.correct,
      image: im.image,
      imageAlt: im.alt,
      explanation: im.explanation,
      difficulty: im.difficulty,
    });
  });

  mapQuestions.forEach((m, i) => {
    bank.push({
      id: `wmap-${i + 1}`,
      category: 'worldmap',
      type: 'map',
      text: `باستخدام الخريطة التفاعلية بالأسفل: في أي قارة تقع دولة «${m.country}»؟ اضغط على القارة الصحيحة.`,
      options: [],
      answer: 0,
      correctText: CONTINENTS[m.continent],
      continent: m.continent,
      topic: m.country,
      explanation: `تقع ${m.country} في قارة ${CONTINENTS[m.continent]}.`,
      difficulty: m.difficulty,
    });
  });

  orderingSets.forEach((s, i) => {
    bank.push({
      id: `ord-${i + 1}`,
      category: 'ordering',
      type: 'order',
      text: s.title,
      options: [],
      answer: 0,
      correctText: s.events.map((e) => e[0]).join(' ← '),
      topic: s.events[0][0],
      events: s.events.map((e) => ({ label: e[0], year: e[1] })),
      explanation: s.explanation,
      difficulty: (s.difficulty ?? 2) as Difficulty,
      source: s.source,
    });
  });

  return bank;
}

export const BANK: Question[] = buildBank();

export function questionsOf(category: CategoryId, extra: Question[] = []): Question[] {
  return [...BANK.filter((q) => q.category === category), ...extra.filter((q) => q.category === category)];
}

export function countOf(category: CategoryId, extra: Question[] = []): number {
  return questionsOf(category, extra).length;
}

export default BANK;
