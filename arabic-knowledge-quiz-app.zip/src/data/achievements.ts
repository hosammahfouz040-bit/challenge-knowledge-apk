import type { AppState } from '../types';
import { levelFromXp } from '../lib/utils';
import type { LucideIcon } from 'lucide-react';
import {
  Footprints, Gamepad2, Crown, Target, Crosshair, Star, Flame, Zap, CalendarCheck2,
  CalendarRange, Trophy, Compass, BookOpenCheck, HeartPulse, GraduationCap, Sparkles,
} from 'lucide-react';

export interface AchievementDef {
  id: string;
  title: string;
  desc: string;
  icon: LucideIcon;
  target: number;
  value: (s: AppState) => number;
}

const catsPlayed = (s: AppState) => Object.values(s.stats.perCategory).filter((c) => (c?.answered ?? 0) > 0).length;

export const ACHIEVEMENTS: AchievementDef[] = [
  { id: 'first-step', title: 'الخطوة الأولى', desc: 'أكمل أول لعبة لك في تحدي المعرفة', icon: Footprints, target: 1, value: (s) => s.stats.games },
  { id: 'player-10', title: 'لاعب مجتهد', desc: 'العب 10 ألعاب كاملة', icon: Gamepad2, target: 10, value: (s) => s.stats.games },
  { id: 'player-50', title: 'محترف التحدي', desc: 'العب 50 لعبة كاملة', icon: Crown, target: 50, value: (s) => s.stats.games },
  { id: 'correct-100', title: 'مئوية المعرفة', desc: 'أجب إجابة صحيحة على 100 سؤال', icon: Target, target: 100, value: (s) => s.stats.correct },
  { id: 'correct-500', title: 'العقل الموسوعي', desc: 'أجب إجابة صحيحة على 500 سؤال', icon: Crosshair, target: 500, value: (s) => s.stats.correct },
  { id: 'perfect-1', title: 'لعبة بلا أخطاء', desc: 'أنهِ لعبة كاملة دون أي خطأ', icon: Star, target: 1, value: (s) => s.stats.perfectGames },
  { id: 'perfect-5', title: 'الكمال عادة', desc: 'حقق 5 ألعاب مثالية دون أخطاء', icon: Sparkles, target: 5, value: (s) => s.stats.perfectGames },
  { id: 'streak-8', title: 'سلسلة نارية', desc: 'حقق 8 إجابات صحيحة متتالية في لعبة واحدة', icon: Flame, target: 8, value: (s) => s.stats.bestStreak },
  { id: 'streak-15', title: 'سلسلة أسطورية', desc: 'حقق 15 إجابة صحيحة متتالية', icon: Zap, target: 15, value: (s) => s.stats.bestStreak },
  { id: 'daily-1', title: 'بطل اليوم', desc: 'أكمل التحدي اليومي مرة واحدة', icon: CalendarCheck2, target: 1, value: (s) => s.stats.dailyDone },
  { id: 'daily-7', title: 'ملتزم الأسبوع', desc: 'أكمل التحدي اليومي 7 مرات', icon: CalendarRange, target: 7, value: (s) => s.stats.dailyDone },
  { id: 'score-500', title: 'قنّاص النقاط', desc: 'سجّل 500 نقطة أو أكثر في لعبة واحدة', icon: Trophy, target: 500, value: (s) => s.stats.bestScore },
  { id: 'explorer', title: 'مستكشف الأقسام', desc: 'العب في 6 أقسام مختلفة على الأقل', icon: Compass, target: 6, value: catsPlayed },
  { id: 'reviewer', title: 'المراجع الدؤوب', desc: 'صحّح 20 سؤالًا في تدريب مراجعة الأخطاء', icon: BookOpenCheck, target: 20, value: (s) => s.stats.reviewedCorrect },
  { id: 'survivor', title: 'الناجي الأخير', desc: 'اجتز 15 سؤالًا في وضع البقاء', icon: HeartPulse, target: 15, value: (s) => s.stats.bestSurvival },
  { id: 'level-5', title: 'عقل مستنير', desc: 'صِل إلى المستوى الخامس', icon: GraduationCap, target: 5, value: (s) => levelFromXp(s.profile.xp) },
  { id: 'level-10', title: 'حارس الحكمة', desc: 'صِل إلى المستوى العاشر', icon: Crown, target: 10, value: (s) => levelFromXp(s.profile.xp) },
];

export default ACHIEVEMENTS;
