import type { Difficulty, Question } from '../types';
import { mulberry32, shuffle } from './utils';

// مولّد ألغاز رقمية ومنطقية حقيقي: يبني السؤال والإجابة والتفسير برمجيًا ويتحقق منها حسابيًا.
// تُستخدم هذه الألغاز المولّدة لتجديد بنك «ألغاز الذكاء» بلا حدود وبإجابات مضمونة الصحة.

let counter = 0;

function makeOptions(correct: number, rng: () => number, spread = 6): string[] {
  const opts = new Set<number>([correct]);
  const candidates = [correct + 1, correct - 1, correct + 2, correct - 2, correct + 5, correct - 5, correct + 10, correct - 10, correct + spread, correct - spread, correct * 2, correct + 3];
  for (const c of candidates) {
    if (opts.size >= 4) break;
    if (c !== correct) opts.add(c);
  }
  let k = 3;
  while (opts.size < 4) {
    opts.add(correct + k * 2);
    k++;
  }
  return shuffle([...opts].map(String), rng);
}

function base(text: string, correct: number, explanation: string, difficulty: Difficulty, rng: () => number, spread?: number): Question {
  const options = makeOptions(correct, rng, spread);
  counter++;
  return {
    id: `gen-${Date.now().toString(36)}-${counter}`,
    category: 'puzzles',
    type: 'mcq',
    text,
    options,
    answer: options.indexOf(String(correct)),
    correctText: String(correct),
    explanation,
    difficulty,
    generated: true,
  };
}

const pick = (rng: () => number, min: number, max: number) => min + Math.floor(rng() * (max - min + 1));

export function generatePuzzle(rng: () => number, difficulty: Difficulty = 2): Question {
  const kind = pick(rng, 0, 8);
  switch (kind) {
    case 0: {
      // متتالية حسابية
      const a = pick(rng, 2, 30);
      const d = pick(rng, 2, 12);
      const terms = [0, 1, 2, 3, 4].map((i) => a + i * d);
      const ans = a + 5 * d;
      return base(`ما الرقم التالي في النمط: ${terms.join(' ، ')} ، ؟`, ans, `كل رقم يزيد عن سابقه بمقدار ثابت ${d}، فيكون التالي ${terms[4]} + ${d} = ${ans}.`, difficulty, rng);
    }
    case 1: {
      // متتالية هندسية
      const a = pick(rng, 1, 6);
      const r = pick(rng, 2, 3);
      const terms = [0, 1, 2, 3].map((i) => a * Math.pow(r, i));
      const ans = a * Math.pow(r, 4);
      return base(`ما الرقم التالي في النمط: ${terms.join(' ، ')} ، ؟`, ans, `كل رقم يُضرب في ${r}: ${terms[3]} × ${r} = ${ans}.`, difficulty, rng);
    }
    case 2: {
      // ضرب ذهني
      const a = pick(rng, 6, 19);
      const b = pick(rng, 4, 9);
      return base(`احسب ذهنيًا: ${a} × ${b} = ؟`, a * b, `${a} × ${b} = ${a} × ${b} ويمكن حسابها: ${a} × ${b - 1} = ${a * (b - 1)} ثم + ${a} = ${a * b}.`, difficulty, rng);
    }
    case 3: {
      // نسبة مئوية
      const p = [10, 20, 25, 50, 75][pick(rng, 0, 4)];
      const n = pick(rng, 2, 12) * (p === 25 || p === 75 ? 40 : 50);
      const ans = (n * p) / 100;
      return base(`ما قيمة ${p}% من العدد ${n}؟`, ans, `${p}% من ${n} = ${n} × ${p} ÷ 100 = ${ans}.`, difficulty, rng);
    }
    case 4: {
      // مربعات
      const n = pick(rng, 4, 8);
      const terms = [1, 2, 3, 4].map((i) => (n + i - 1) ** 2);
      const ans = (n + 4) ** 2;
      return base(`ما الرقم التالي: ${terms.join(' ، ')} ، ؟`, ans, `الأرقام مربعات أعداد متتالية تبدأ من ${n}، والمربع التالي ${n + 4}² = ${ans}.`, difficulty, rng);
    }
    case 5: {
      // مجموع ثم إضافات متنامية
      const a = pick(rng, 3, 15);
      const diffs = [2, 4, 6, 8];
      const terms = [a];
      diffs.forEach((d) => terms.push(terms[terms.length - 1] + d));
      const ans = terms[4] + 10;
      return base(`ما الرقم التالي: ${terms.join(' ، ')} ، ؟`, ans, `الزيادات تتنامى: +2 ثم +4 ثم +6 ثم +8 ثم +10، فيكون التالي ${terms[4]} + 10 = ${ans}.`, difficulty, rng);
    }
    case 6: {
      // مسألة شراء
      const unit = pick(rng, 2, 9);
      const n1 = pick(rng, 2, 6);
      const n2 = n1 + pick(rng, 2, 5);
      const total = unit * n1;
      return base(`إذا كان ثمن ${n1} أقلام ${total} ريالًا، فما ثمن ${n2} أقلام من النوع نفسه؟`, unit * n2, `ثمن القلم الواحد ${total} ÷ ${n1} = ${unit} ريالات، وثمن ${n2} أقلام = ${unit} × ${n2} = ${unit * n2} ريالًا.`, difficulty, rng);
    }
    case 7: {
      // جذر تربيعي
      const r = pick(rng, 6, 20);
      return base(`ما العدد الذي إذا ضربته في نفسه أعطاك ${r * r}؟`, r, `${r} × ${r} = ${r * r}، إذن العدد هو ${r} وهو الجذر التربيعي لـ ${r * r}.`, difficulty, rng);
    }
    default: {
      // أعداد متتالية مجموعها معلوم
      const mid = pick(rng, 8, 40);
      const sum = mid * 3;
      return base(`ثلاثة أعداد صحيحة متتالية مجموعها ${sum}، فما أكبرها؟`, mid + 1, `الأعداد هي ${mid - 1} و${mid} و${mid + 1} ومجموعها ${sum}، فأكبرها ${mid + 1}.`, difficulty, rng);
    }
  }
}

export function generatePuzzles(count: number, seed: number, difficulty: Difficulty = 2): Question[] {
  const rng = mulberry32(seed);
  const seen = new Set<string>();
  const out: Question[] = [];
  let guard = 0;
  while (out.length < count && guard < count * 30) {
    guard++;
    const q = generatePuzzle(rng, difficulty);
    if (seen.has(q.text)) continue;
    seen.add(q.text);
    out.push(q);
  }
  return out;
}
