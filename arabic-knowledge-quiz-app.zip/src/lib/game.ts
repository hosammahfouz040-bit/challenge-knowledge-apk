import type { AppState, GameConfig, OrderEvent, Question } from '../types';
import { BANK } from '../data';
import { generateForCategory, generateMixedPack } from './gengeneral';
import { mulberry32, seedFromDate, shuffle } from './utils';

export interface DisplayQ {
  q: Question;
  options: string[];
  answerIdx: number;
  events: OrderEvent[]; // لأسئلة الترتيب: ترتيب العرض المشوش
}

export interface Session {
  config: GameConfig;
  items: DisplayQ[];
  recycled: boolean; // هل أعيد استخدام أسئلة سبق لعبها لنفاد الجديد؟
}

function toDisplay(q: Question, rng: () => number): DisplayQ {
  if (q.type === 'order' && q.events) {
    return { q, options: [], answerIdx: 0, events: shuffle(q.events, rng) };
  }
  if (q.type === 'map') {
    return { q, options: [], answerIdx: 0, events: [] };
  }
  const options = shuffle(q.options, rng);
  return { q, options, answerIdx: options.indexOf(q.correctText), events: [] };
}

export function poolFor(config: GameConfig, state: AppState): Question[] {
  const all = [...BANK, ...state.customQuestions];
  let pool = config.category === 'all' ? all : all.filter((q) => q.category === config.category);
  if (config.mode === 'daily') {
    pool = pool.filter((q) => q.type === 'mcq' || q.type === 'image');
  }
  if (config.mode === 'quick' || config.mode === 'survival') {
    pool = pool.filter((q) => q.type !== 'order');
  }
  if (config.difficulty !== 0) {
    pool = pool.filter((q) => q.difficulty === config.difficulty);
  }
  return pool;
}

export function availableCount(config: GameConfig, state: AppState): { total: number; unused: number } {
  const pool = poolFor(config, state);
  const used = new Set(state.usedIds);
  return { total: pool.length, unused: pool.filter((q) => !used.has(q.id)).length };
}

export function buildSession(config: GameConfig, state: AppState): Session {
  const pool = poolFor(config, state);
  const want = config.mode === 'quick' ? 40 : config.mode === 'survival' ? 60 : config.mode === 'daily' ? 10 : config.count;

  if (config.mode === 'daily') {
    const rng = mulberry32(seedFromDate());
    const picked = shuffle(pool, rng).slice(0, Math.min(want, pool.length));
    return { config, items: picked.map((q) => toDisplay(q, rng)), recycled: false };
  }

  const used = new Set(state.usedIds);
  const rng = Math.random;
  const fresh = shuffle(pool.filter((q) => !used.has(q.id)), rng);
  const stale = shuffle(pool.filter((q) => used.has(q.id)), rng);
  let picked = [...fresh, ...stale].slice(0, want);
  const recycled = fresh.length < want && picked.length > 0;

  // تجديد شامل لكل الأقسام: عند نفاد الأسئلة الجديدة تُولّد أسئلة برمجية موثوقة
  // من جداول حقائق وحسابات داخل التطبيق (عواصم، كواكب، سور، فيتامينات، أبطال، ترتيب أحداث...)
  if (picked.length < want) {
    const exclude = new Set<string>([...BANK.map((x) => x.text), ...state.customQuestions.map((x) => x.text)]);
    picked.forEach((x) => exclude.add(x.text));
    const need = want - picked.length;
    const allowOrder = config.mode !== 'quick' && config.mode !== 'survival';
    const seed = (Date.now() % 100000) + picked.length * 131 + need * 7;
    const gen =
      config.category === 'all'
        ? generateMixedPack(need, seed, exclude, allowOrder)
        : generateForCategory(config.category, need, seed, exclude, allowOrder);
    picked = [...picked, ...gen];
  }

  return { config, items: picked.map((q) => toDisplay(q, rng)), recycled };
}

export function buildReviewSession(questions: Question[]): Session {
  const rng = Math.random;
  const picked = shuffle(questions, rng).slice(0, 20);
  return {
    config: { mode: 'review', category: 'all', difficulty: 0, count: picked.length },
    items: picked.map((q) => toDisplay(q, rng)),
    recycled: false,
  };
}

// مدة السؤال بالثواني لكل وضع (0 = بلا مؤقّت)
export function secondsPerQuestion(mode: GameConfig['mode']): number {
  switch (mode) {
    case 'classic': return 30;
    case 'timed': return 15;
    case 'mixed': return 20;
    case 'daily': return 20;
    case 'survival': return 20;
    case 'quick': return 0;
    case 'review': return 0;
    default: return 20;
  }
}

export function modeLabel(mode: GameConfig['mode']): string {
  return {
    classic: 'اللعب الكلاسيكي',
    timed: 'جولات محددة بالوقت',
    quick: 'التحدي السريع',
    survival: 'وضع البقاء',
    mixed: 'الوضع المختلط',
    daily: 'التحدي اليومي',
    review: 'مراجعة الأخطاء',
  }[mode];
}
