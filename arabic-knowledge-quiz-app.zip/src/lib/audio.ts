// مؤثرات صوتية مولّدة برمجيًا عبر WebAudio (بدون أي ملفات خارجية)

let ctx: AudioContext | null = null;

function getCtx(): AudioContext | null {
  try {
    if (!ctx) {
      const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      ctx = new AC();
    }
    if (ctx.state === 'suspended') void ctx.resume();
    return ctx;
  } catch {
    return null;
  }
}

function tone(freq: number, start: number, dur: number, type: OscillatorType = 'sine', vol = 0.12) {
  const ac = getCtx();
  if (!ac) return;
  const osc = ac.createOscillator();
  const gain = ac.createGain();
  const t0 = ac.currentTime + start;
  osc.type = type;
  osc.frequency.setValueAtTime(freq, t0);
  gain.gain.setValueAtTime(0.0001, t0);
  gain.gain.exponentialRampToValueAtTime(vol, t0 + 0.02);
  gain.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
  osc.connect(gain).connect(ac.destination);
  osc.start(t0);
  osc.stop(t0 + dur + 0.05);
}

export const sfx = {
  click() {
    tone(520, 0, 0.07, 'triangle', 0.06);
  },
  correct() {
    tone(659, 0, 0.14, 'sine', 0.13);
    tone(880, 0.09, 0.2, 'sine', 0.13);
  },
  wrong() {
    tone(196, 0, 0.22, 'sawtooth', 0.07);
    tone(147, 0.08, 0.26, 'sawtooth', 0.06);
  },
  tick() {
    tone(980, 0, 0.05, 'square', 0.045);
  },
  lifeline() {
    tone(740, 0, 0.1, 'triangle', 0.1);
    tone(1108, 0.07, 0.14, 'triangle', 0.09);
  },
  finish() {
    [523, 659, 784, 1046].forEach((f, i) => tone(f, i * 0.11, 0.24, 'sine', 0.12));
  },
  unlock() {
    [784, 988, 1175].forEach((f, i) => tone(f, i * 0.09, 0.2, 'triangle', 0.11));
  },
};
