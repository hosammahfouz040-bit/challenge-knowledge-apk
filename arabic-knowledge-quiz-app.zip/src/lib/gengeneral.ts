import type { CategoryId, Question } from '../types';
import { mulberry32, shuffle, hashString } from './utils';
import { generatePuzzle } from './generator';

// مولّد أسئلة شامل لكل الأقسام.
// جميع الأسئلة تُبنى من جداول حقائق موثوقة أو عمليات حسابية داخل هذا الملف،
// وتُتحقق إجاباتها برمجيًا قبل عرضها — لا توجد أسئلة وهمية أو إجابات مرتجلة.

let counter = 0;

function q(
  category: CategoryId,
  text: string,
  options: string[],
  correct: string,
  explanation: string,
  extra: Partial<Question> = {},
): Question {
  counter++;
  const shuffled = shuffle(options);
  return {
    id: `geng-${Date.now().toString(36)}-${counter}`,
    category,
    type: 'mcq',
    text,
    options: shuffled,
    answer: shuffled.indexOf(correct),
    correctText: correct,
    explanation,
    difficulty: 2,
    generated: true,
    topic: correct,
    ...extra,
  };
}

function opts4(correct: string, pool: string[], rng: () => number): string[] {
  const uniquePool = [...new Set(pool.filter((v) => v !== correct))];
  const wrongs = shuffle(uniquePool, rng).slice(0, 3);
  return [correct, ...wrongs];
}

function numOpts(correct: number, rng: () => number, deltas = [1, -1, 2, -2, 5, -5, 10, -10, 3, -3]): string[] {
  const set = new Set<number>([correct]);
  for (const d of shuffle(deltas, rng)) {
    if (set.size >= 4) break;
    const v = Math.round((correct + d) * 100) / 100;
    if (v !== correct) set.add(v);
  }
  let k = 4;
  while (set.size < 4) set.add(correct + k++);
  return [...set].map((n) => (Number.isInteger(n) ? String(n) : n.toFixed(1)));
}

const numQ = (
  category: CategoryId,
  text: string,
  correct: number,
  explanation: string,
  rng: () => number,
  extra: Partial<Question> = {},
): Question => {
  const options = numOpts(correct, rng);
  return {
    id: `genn-${Date.now().toString(36)}-${++counter}`,
    category,
    type: 'mcq',
    text,
    options,
    answer: options.indexOf(Number.isInteger(correct) ? String(correct) : correct.toFixed(1)),
    correctText: Number.isInteger(correct) ? String(correct) : correct.toFixed(1),
    explanation,
    difficulty: 2,
    generated: true,
    ...extra,
  };
};

const pick = <T,>(rng: () => number, arr: readonly T[]): T => arr[Math.floor(rng() * arr.length)];
const ri = (rng: () => number, min: number, max: number) => min + Math.floor(rng() * (max - min + 1));

// ================= جداول حقائق موثوقة =================

const CAPITALS: [string, string, string][] = [
  ['فنزويلا', 'كاراكاس', 'أمريكا الجنوبية'], ['الإكوادور', 'كيتو', 'أمريكا الجنوبية'], ['باراغواي', 'أسونسيون', 'أمريكا الجنوبية'],
  ['الأوروغواي', 'مونتيفيديو', 'أمريكا الجنوبية'], ['غواتيمالا', 'مدينة غواتيمالا', 'أمريكا الشمالية'], ['هندوراس', 'تيغوسيغالبا', 'أمريكا الشمالية'],
  ['نيكاراغوا', 'ماناغوا', 'أمريكا الشمالية'], ['جامايكا', 'كينغستون', 'أمريكا الشمالية'], ['ميانمار', 'نايبيداو', 'آسيا'],
  ['لاوس', 'فينتيان', 'آسيا'], ['كمبوديا', 'بنوم بنه', 'آسيا'], ['نيبال', 'كاتماندو', 'آسيا'],
  ['بوتان', 'تيمفو', 'آسيا'], ['المالديف', 'ماليه', 'آسيا'], ['أوزبكستان', 'طشقند', 'آسيا'],
  ['تركمانستان', 'عشق آباد', 'آسيا'], ['أذربيجان', 'باكو', 'آسيا'], ['جورجيا', 'تبليسي', 'آسيا'],
  ['أرمينيا', 'يريفان', 'آسيا'], ['مولدوفا', 'كيشيناو', 'أوروبا'], ['بيلاروس', 'مينسك', 'أوروبا'],
  ['صربيا', 'بلغراد', 'أوروبا'], ['كرواتيا', 'زغرب', 'أوروبا'], ['البوسنة والهرسك', 'سراييفو', 'أوروبا'],
  ['الجبل الأسود', 'بودغوريتسا', 'أوروبا'], ['مقدونيا الشمالية', 'سكوبي', 'أوروبا'], ['ألبانيا', 'تيرانا', 'أوروبا'],
  ['سلوفينيا', 'ليوبليانا', 'أوروبا'], ['سلوفاكيا', 'براتيسلافا', 'أوروبا'], ['إستونيا', 'تالين', 'أوروبا'],
  ['لاتفيا', 'ريغا', 'أوروبا'], ['ليتوانيا', 'فيلنيوس', 'أوروبا'], ['أنغولا', 'لواندا', 'إفريقيا'],
  ['موزمبيق', 'مابوتو', 'إفريقيا'], ['زامبيا', 'لوساكا', 'إفريقيا'], ['زيمبابوي', 'هراري', 'إفريقيا'],
  ['بوتسوانا', 'غابورون', 'إفريقيا'], ['ناميبيا', 'ويندهوك', 'إفريقيا'], ['مدغشقر', 'أنتاناناريفو', 'إفريقيا'],
  ['مالي', 'باماكو', 'إفريقيا'], ['النيجر', 'نيامي', 'إفريقيا'], ['تشاد', 'نجامينا', 'إفريقيا'],
  ['السنغال', 'داكار', 'إفريقيا'], ['أوغندا', 'كمبالا', 'إفريقيا'], ['رواندا', 'كيغالي', 'إفريقيا'],
  ['تنزانيا', 'دودوما', 'إفريقيا'],
];

const EVENTS: [string, number][] = [
  ['معركة واترلو وهزيمة نابليون', 1815], ['إنشاء الصليب الأحمر الدولي', 1863], ['حصول كارل بنز على براءة أول سيارة', 1886],
  ['افتتاح برج إيفل في باريس', 1889], ['تأسيس اللجنة الأولمبية والألعاب الحديثة الأولى', 1896], ['إعلان ميثاق الأمم المتحدة ودخوله حيز النفاذ', 1945],
  ['تأسيس منظمة الصحة العالمية', 1948], ['انطلاق شبكة أربانت نواة الإنترنت', 1969], ['طرح أول هاتف محمول تجاري (موتورولا)', 1983],
  ['توحيد ألمانيا رسميًا بعد سقوط الجدار', 1990], ['إتاحة شبكة الويب العالمية للجمهور', 1991], ['استنساخ النعجة دولي', 1996],
  ['إطلاق موقع يوتيوب', 2005], ['افتتاح برج خليفة في دبي أطول بناء في العالم', 2010], ['هبوط المسبار الصيني على الجانب البعيد للقمر', 2019],
];

const ORDER_EVENTS: [string, number][] = [
  ['توحيد الملك مينا قطرَي مصر', -3100], ['بناء الهرم الأكبر بالجيزة', -2560], ['أول ألعاب أولمبية في اليونان القديمة', -776],
  ['الهجرة النبوية إلى المدينة المنورة', 622], ['فتح الأندلس بقيادة طارق بن زياد', 711], ['تأسيس مدينة القاهرة', 969],
  ['معركة حطين وتحرير القدس', 1187], ['فتح القسطنطينية', 1453], ['وصول كولومبوس إلى الأمريكتين', 1492],
  ['اندلاع الثورة الفرنسية', 1789], ['افتتاح قناة السويس', 1869], ['اندلاع الحرب العالمية الأولى', 1914],
  ['تأسيس منظمة الأمم المتحدة', 1945], ['هبوط الإنسان على سطح القمر', 1969], ['سقوط جدار برلين', 1989],
  ['استضافة قطر أول كأس عالم عربية', 2022],
];

const PLANETS: { name: string; order: number; yearDays: number; moons: number | null }[] = [
  { name: 'عطارد', order: 1, yearDays: 88, moons: 0 },
  { name: 'الزهرة', order: 2, yearDays: 225, moons: 0 },
  { name: 'الأرض', order: 3, yearDays: 365, moons: 1 },
  { name: 'المريخ', order: 4, yearDays: 687, moons: 2 },
  { name: 'المشتري', order: 5, yearDays: 4333, moons: null },
  { name: 'زحل', order: 6, yearDays: 10759, moons: null },
  { name: 'أورانوس', order: 7, yearDays: 30687, moons: null },
  { name: 'نبتون', order: 8, yearDays: 60190, moons: null },
];

const ELEMENTS: [string, string, number][] = [
  ['الهيدروجين', 'H', 1], ['الهيليوم', 'He', 2], ['الكربون', 'C', 6], ['النيتروجين', 'N', 7], ['الأكسجين', 'O', 8],
  ['الصوديوم', 'Na', 11], ['المغنيسيوم', 'Mg', 12], ['الألمنيوم', 'Al', 13], ['السيليكون', 'Si', 14], ['الكبريت', 'S', 16],
  ['الكلور', 'Cl', 17], ['البوتاسيوم', 'K', 19], ['الكالسيوم', 'Ca', 20], ['الحديد', 'Fe', 26], ['النحاس', 'Cu', 29],
  ['الزنك', 'Zn', 30], ['الفضة', 'Ag', 47], ['الذهب', 'Au', 79], ['الزئبق', 'Hg', 80], ['الرصاص', 'Pb', 82],
];

const SURAHS: [string, number, 'مكية' | 'مدنية'][] = [
  ['الفاتحة', 7, 'مكية'], ['البقرة', 286, 'مدنية'], ['آل عمران', 200, 'مدنية'], ['النساء', 176, 'مدنية'],
  ['المائدة', 120, 'مدنية'], ['يوسف', 111, 'مكية'], ['الكهف', 110, 'مكية'], ['مريم', 98, 'مكية'],
  ['طه', 135, 'مكية'], ['النمل', 93, 'مكية'], ['يس', 83, 'مكية'], ['الرحمن', 78, 'مكية'],
  ['الواقعة', 96, 'مكية'], ['الملك', 30, 'مكية'], ['الإخلاص', 4, 'مكية'], ['الكوثر', 3, 'مكية'],
  ['الفلق', 5, 'مكية'], ['الناس', 6, 'مكية'],
];

const HIJRI_MONTHS = ['محرم', 'صفر', 'ربيع الأول', 'ربيع الآخر', 'جمادى الأولى', 'جمادى الآخرة', 'رجب', 'شعبان', 'رمضان', 'شوال', 'ذو القعدة', 'ذو الحجة'];

const PROPHETS_PEOPLE: [string, string][] = [
  ['هود عليه السلام', 'قوم عاد'], ['صالح عليه السلام', 'قوم ثمود'], ['شعيب عليه السلام', 'أهل مدين (أصحاب الأيكة)'],
  ['يونس عليه السلام', 'أهل نينوى'], ['موسى عليه السلام', 'بنو إسرائيل وفرعون مصر'], ['لوط عليه السلام', 'قوم لوط (أهل سدوم)'],
  ['إسماعيل عليه السلام', 'أهل مكة وقبيلة جرهم'], ['نوح عليه السلام', 'قومه من عبدة الأوثان قبل الطوفان'],
];

const NUTRIENTS: [string, string, string][] = [
  // الاسم، مصدر غني، أثر النقص الشائع
  ['فيتامين د', 'الأسماك الدهنية وأشعة الشمس', 'لين العظام وهشاشتها'],
  ['فيتامين ج', 'الحمضيات والفلفل الملون', 'نزيف اللثة وضعف التئام الجروح (الأسقربوط)'],
  ['الحديد', 'اللحوم الحمراء والعدس', 'فقر الدم والشحوب والإرهاق'],
  ['الكالسيوم', 'الحليب ومشتقاته والسردين', 'ضعف العظام والأسنان'],
  ['اليود', 'الملح الميودن والأسماك البحرية', 'تضخم الغدة الدرقية'],
  ['فيتامين أ', 'الجزر والكبد والبطاطا الحلوة', 'العشى الليلي وضعف الإبصار'],
  ['فيتامين ب12', 'اللحوم والبيض والحليب', 'فقر الدم وتنميل الأطراف'],
  ['الألياف الغذائية', 'البقوليات والخضار والحبوب الكاملة', 'الإمساك واضطراب الهضم'],
];

const INVENTIONS: [string, string, number][] = [
  ['التلغراف الكهربائي العملي', 'صمويل مورس', 1837],
  ['أول بطارية كهربائية', 'أليساندرو فولتا', 1800],
  ['البارومتر لقياس الضغط الجوي', 'إيفانجليستا توريشيلي', 1643],
  ['نسيج النايلون الصناعي', 'والاس كاروثرز', 1935],
  ['التخدير الجراحي بالإيثر علنًا', 'ويليام مورتون', 1846],
  ['ميزان الحرارة الزئبقي الدقيق', 'دانيال فهرنهايت', 1714],
  ['أول مجهر مركب بدائي', 'زكرياس يانسن', 1590],
  ['مبدأ المحرك والمولد الكهربائي', 'مايكل فاراداي', 1821],
  ['التصوير الفوتوغرافي العملي (الداغيرية)', 'لوي داغير', 1839],
  ['أول بلاستيك صناعي (الباكليت)', 'ليو بايكلاند', 1907],
];

const WC_WINNERS: [number, string][] = [
  [1930, 'الأوروغواي'], [1934, 'إيطاليا'], [1938, 'إيطاليا'], [1950, 'الأوروغواي'], [1954, 'ألمانيا'],
  [1958, 'البرازيل'], [1962, 'البرازيل'], [1966, 'إنجلترا'], [1970, 'البرازيل'], [1974, 'ألمانيا'],
  [1978, 'الأرجنتين'], [1982, 'إيطاليا'], [1986, 'الأرجنتين'], [1990, 'ألمانيا'], [1994, 'البرازيل'],
  [1998, 'فرنسا'], [2002, 'البرازيل'], [2006, 'إيطاليا'], [2010, 'إسبانيا'], [2014, 'ألمانيا'],
  [2018, 'فرنسا'], [2022, 'الأرجنتين'],
];

const ATHLETES: [string, string][] = [
  ['هشام الكروج', 'ألعاب القوى (العدو المتوسط)'], ['كرم جابر', 'المصارعة الرومانية'], ['محمد علي كلاي', 'الملاكمة'],
  ['يوسين بولت', 'ألعاب القوى (العدو السريع)'], ['مايكل فيلبس', 'السباحة'], ['ماغنوس كارلسن', 'الشطرنج'],
  ['رافاييل نادال', 'التنس الأرضي'], ['لويس هاميلتون', 'سباقات الفورمولا 1'], ['ناديا كومانتشي', 'الجمباز الفني'],
  ['فريال أشرف', 'الكاراتيه'], ['سفيان البقالي', 'ألعاب القوى (الموانع)'], ['معتز برشم', 'ألعاب القوى (الوثب العالي)'],
];

const PLURALS: [string, string][] = [
  ['كتاب', 'كتب'], ['قلم', 'أقلام'], ['باب', 'أبواب'], ['نجم', 'نجوم'], ['قلب', 'قلوب'],
  ['جبل', 'جبال'], ['نهر', 'أنهار'], ['شجرة', 'أشجار'], ['ولد', 'أولاد'], ['يوم', 'أيام'],
  ['صديق', 'أصدقاء'], ['طريق', 'طرق'], ['مدينة', 'مدن'], ['سنة', 'سنوات'], ['عين', 'عيون'],
];

const ANTONYMS: [string, string][] = [
  ['كبير', 'صغير'], ['سعيد', 'حزين'], ['سريع', 'بطيء'], ['قوي', 'ضعيف'], ['غني', 'فقير'],
  ['شجاع', 'جبان'], ['صادق', 'كاذب'], ['واسع', 'ضيق'], ['خفيف', 'ثقيل'], ['قديم', 'جديد'],
  ['حار', 'بارد'], ['بعيد', 'قريب'],
];

const AUTHORS: [string, string][] = [
  ['رجال في الشمس', 'غسان كنفاني'], ['اللص والكلاب', 'نجيب محفوظ'], ['قنديل أم هاشم', 'يحيى حقي'],
  ['الأجنحة المتكسرة', 'جبران خليل جبران'], ['في بيتنا رجل', 'إحسان عبد القدوس'], ['الأرض', 'عبد الرحمن الشرقاوي'],
  ['عودة الروح', 'توفيق الحكيم'], ['إبراهيم الكاتب', 'إبراهيم المازني'], ['الأرواح المتمردة', 'جبران خليل جبران'],
  ['زقاق المدق', 'نجيب محفوظ'],
];

const FLAGS: [string, string][] = [
  ['اليونان', 'صليب أبيض على خلفية زرقاء وبيضاء مخططة'], ['الأرجنتين', 'شمس صفراء بملامح وجه (شمس مايو) في الوسط'],
  ['مصر', 'نسر صلاح الدين الذهبي على ألوان حمراء وبيضاء وسوداء'], ['الأردن', 'نجمة بيضاء سباعية على شيفرون أحمر'],
  ['السويد', 'صليب أصفر على خلفية زرقاء (الصليب الإسكندنافي)'], ['فنلندا', 'صليب أزرق على خلفية بيضاء'],
  ['الهند', 'عجلة أشوكا الزرقاء ذات 24 قضيبًا في الوسط'], ['الصين', 'خمس نجوم صفراء على خلفية حمراء'],
  ['إندونيسيا', 'شريط أحمر فوق شريط أبيض فقط'], ['المكسيك', 'نسر يقف على صبار ويمسك أفعى في الوسط'],
  ['البرتغال', 'درع وأسطوانة ملاحية (أسطرلاب) على أخضر وأحمر'], ['كوريا الجنوبية', 'دائرة حمراء وزرقاء (تايجيك) وأربعة رموز سوداء في الزوايا'],
];

const CONTINENT_AR: Record<string, string> = {
  africa: 'إفريقيا', asia: 'آسيا', europe: 'أوروبا', namerica: 'أمريكا الشمالية', samerica: 'أمريكا الجنوبية', oceania: 'أوقيانيا',
};
const CONTINENT_TO_KEY: Record<string, string> = Object.fromEntries(Object.entries(CONTINENT_AR).map(([k, v]) => [v, k]));

// ================= مولّدات الأقسام =================

function genScience(rng: () => number): Question {
  const kind = ri(rng, 0, 4);
  if (kind === 0) {
    const I = ri(rng, 2, 12); const R = ri(rng, 3, 15); const V = I * R;
    return numQ('science', `في دائرة كهربائية التيار ${I} أمبير والمقاومة ${R} أوم، فكم الجهد (الفولت)؟`, V, `بقانون أوم: الجهد = التيار × المقاومة = ${I} × ${R} = ${V} فولت.`, rng, { topic: 'قانون أوم' });
  }
  if (kind === 1) {
    const v = pick(rng, [30, 45, 60, 80, 90, 100, 120]); const t = ri(rng, 2, 6);
    return numQ('science', `تسير سيارة بسرعة ثابتة ${v} كم/ساعة، فكم كيلومترًا تقطع في ${t} ساعات؟`, v * t, `المسافة = السرعة × الزمن = ${v} × ${t} = ${v * t} كم.`, rng, { topic: 'قوانين الحركة' });
  }
  if (kind === 2) {
    const conv: [number, string, string, number][] = [
      [ri(rng, 2, 9), 'كيلومترات', 'مترًا', 1000], [ri(rng, 2, 9), 'كيلوغرامات', 'غرامًا', 1000],
      [ri(rng, 2, 8), 'ساعات', 'دقيقة', 60], [ri(rng, 2, 9), 'لترات', 'مليلترًا', 1000], [ri(rng, 2, 9), 'أمتار', 'سنتيمترًا', 100],
    ];
    const [n, from, to, f] = pick(rng, conv);
    return numQ('science', `كم ${to} في ${n} ${from}؟`, n * f, `${n} ${from} = ${n} × ${f} = ${n * f} ${to}.`, rng, { topic: 'تحويل الوحدات' });
  }
  if (kind === 3) {
    const [name, sym, z] = pick(rng, ELEMENTS);
    if (rng() < 0.5) {
      return q('science', `ما الرمز الكيميائي لعنصر ${name}؟`, opts4(sym, ELEMENTS.map((e) => e[1]), rng), sym, `رمز ${name} هو ${sym} وعدده الذري ${z}.`, { topic: name });
    }
    return numQ('science', `ما العدد الذري لعنصر ${name} (${sym})؟`, z, `العدد الذري لعنصر ${name} هو ${z} أي إن ذرته تحتوي ${z} بروتونًا.`, rng, { topic: name });
  }
  const c = pick(rng, [-10, 0, 5, 20, 25, 30, 37, 50, 100]);
  return numQ('science', `كم درجة كلفن تعادل ${c} درجة مئوية؟`, Math.round(c + 273.15), `كلفن = مئوي + 273.15، أي ${c} + 273.15 ≈ ${Math.round(c + 273.15)} كلفن، والصفر المطلق 0 كلفن = -273.15°م.`, rng, { topic: 'مقياس كلفن' });
}

function genCulture(rng: () => number): Question {
  const kind = ri(rng, 0, 4);
  if (kind === 0) {
    const [s, p] = pick(rng, PLURALS);
    return q('culture', `ما جمع كلمة «${s}»؟`, opts4(p, PLURALS.map((x) => x[1]), rng), p, `جمع «${s}» هو «${p}» في اللغة العربية.`, { topic: `جمع كلمة ${s}` });
  }
  if (kind === 1) {
    const [w, a] = pick(rng, ANTONYMS);
    return q('culture', `ما ضد كلمة «${w}»؟`, opts4(a, ANTONYMS.map((x) => x[1]), rng), a, `ضد «${w}» هو «${a}»، والأضداد توضح المعنى وتقوّي البيان.`, { topic: `ضد كلمة ${w}` });
  }
  if (kind === 2) {
    const words = ['المعرفة', 'الكتاب', 'المدرسة', 'الحديقة', 'السفينة', 'القمر', 'النجمة', 'البحر', 'الشجرة', 'الصديق', 'العلم', 'النور'];
    const w = pick(rng, words);
    let scrambled = shuffle(w.split(''), rng).join('');
    if (scrambled === w) scrambled = w.split('').reverse().join('');
    const others = shuffle(words.filter((x) => x !== w), rng).slice(0, 3);
    return q('culture', `رتّب الحروف التالية لتكوّن كلمة صحيحة: ${scrambled.split('').join(' - ')}`, [w, ...others], w, `بترتيب الحروف نحصل على كلمة «${w}».`, { topic: w });
  }
  if (kind === 3) {
    const words = ['المعرفة', 'الحضارة', 'المكتبة', 'الاستقلال', 'التعليم', 'الجامعة', 'الموسوعة', 'الاستكشاف'];
    const w = pick(rng, words);
    return numQ('culture', `كم عدد حروف كلمة «${w}»؟`, w.length, `كلمة «${w}» تتكون من ${w.length} حروف: ${w.split('').join(' - ')}.`, rng, { topic: undefined });
  }
  const [book, author] = pick(rng, AUTHORS);
  return q('culture', `من مؤلف كتاب/رواية «${book}»؟`, opts4(author, AUTHORS.map((x) => x[1]), rng), author, `«${book}» من أعمال الأديب ${author}.`, { topic: book });
}

function genReligion(rng: () => number): Question {
  const kind = ri(rng, 0, 3);
  if (kind === 0) {
    const i = ri(rng, 0, 11);
    const next = HIJRI_MONTHS[(i + 1) % 12];
    const wrongPool = HIJRI_MONTHS.filter((m) => m !== next && m !== HIJRI_MONTHS[i]);
    return q('religion', `ما الشهر الهجري الذي يلي شهر ${HIJRI_MONTHS[i]}؟`, opts4(next, wrongPool, rng), next, `ترتيب الشهور الهجرية: ${HIJRI_MONTHS.join('، ')}.`, { topic: 'الأشهر الهجرية' });
  }
  if (kind === 1) {
    const [name, ayahs] = pick(rng, SURAHS);
    const pool = shuffle(SURAHS.map((s) => s[1]).filter((n) => n !== ayahs), rng).slice(0, 3).map(String);
    return q('religion', `كم عدد آيات سورة ${name}؟`, [String(ayahs), ...pool], String(ayahs), `عدد آيات سورة ${name} هو ${ayahs} آية بحسب عدّ المصحف المدني المشهور.`, { topic: `سورة ${name}` });
  }
  if (kind === 2) {
    const [prophet, people] = pick(rng, PROPHETS_PEOPLE);
    return q('religion', `إلى أي قوم أُرسل ${prophet}؟`, opts4(people, PROPHETS_PEOPLE.map((x) => x[1]), rng), people, `أُرسل ${prophet} إلى ${people} كما ورد في قصص القرآن الكريم.`, { topic: prophet });
  }
  const madani = pick(rng, SURAHS.filter((s) => s[2] === 'مدنية'));
  const makki = shuffle(SURAHS.filter((s) => s[2] === 'مكية'), rng).slice(0, 3);
  return q(
    'religion',
    'أي السور التالية سورة مدنية (نزلت بعد الهجرة)؟',
    [madani[0], ...makki.map((s) => s[0])],
    madani[0],
    `سورة ${madani[0]} مدنية نزلت بالمدينة المنورة، بينما ${makki.map((s) => s[0]).join(' و')} مكية نزلت قبل الهجرة.`,
    { topic: `سورة ${madani[0]}` },
  );
}

function genGeohist(rng: () => number): Question {
  const kind = ri(rng, 0, 3);
  if (kind <= 1) {
    const [country, capital, continent] = pick(rng, CAPITALS);
    if (kind === 0) {
      return q('geohist', `ما عاصمة ${country}؟`, opts4(capital, CAPITALS.map((c) => c[1]), rng), capital, `${capital} عاصمة ${country} الواقعة في ${continent}.`, { topic: country, more: `${capital} هي عاصمة ${country} وأكبر مدنها مركزًا سياسيًا، وتقع ${country} في قارة ${continent}.` });
    }
    return q('geohist', `${capital} عاصمة أي دولة؟`, opts4(country, CAPITALS.map((c) => c[0]), rng), country, `${capital} عاصمة ${country} في ${continent}.`, { topic: capital, more: `${capital} هي عاصمة ${country} وأكبر مدنها مركزًا سياسيًا، وتقع ${country} في قارة ${continent}.` });
  }
  if (kind === 2) {
    const [ev, year] = pick(rng, EVENTS);
    const pool = shuffle([year - 5, year + 5, year - 12, year + 9, year - 3, year + 20], rng).slice(0, 3).map(String);
    return q('geohist', `في أي عام وقع الحدث التالي: ${ev}؟`, [String(year), ...pool], String(year), `${ev} وقع عام ${year}م.`, { topic: ev });
  }
  const [country, capital, continent] = pick(rng, CAPITALS);
  return q('geohist', `في أي قارة تقع دولة ${country}؟`, opts4(continent, ['إفريقيا', 'آسيا', 'أوروبا', 'أمريكا الشمالية', 'أمريكا الجنوبية', 'أوقيانيا'], rng), continent, `تقع ${country} (عاصمتها ${capital}) في قارة ${continent}.`, { topic: country, more: `تقع ${country} في ${continent} وعاصمتها ${capital}.` });
}

function genSpace(rng: () => number): Question {
  const kind = ri(rng, 0, 3);
  if (kind === 0) {
    const p = pick(rng, PLANETS);
    const others = shuffle(PLANETS.map((x) => x.order).filter((o) => o !== p.order), rng).slice(0, 3).map(String);
    return q('space', `ما ترتيب كوكب ${p.name} من حيث القرب من الشمس؟`, [String(p.order), ...others], String(p.order), `${p.name} هو الكوكب رقم ${p.order} من الشمس في مجموعتنا الشمسية.`, { topic: p.name });
  }
  if (kind === 1) {
    const p = pick(rng, PLANETS);
    const pool = shuffle(PLANETS.map((x) => x.yearDays).filter((y) => y !== p.yearDays), rng).slice(0, 3).map((y) => `${y.toLocaleString('en-US')} يومًا`);
    return q('space', `كم يومًا تستغرق سنة كوكب ${p.name} (دورة كاملة حول الشمس) تقريبًا؟`, [`${p.yearDays.toLocaleString('en-US')} يومًا`, ...pool], `${p.yearDays.toLocaleString('en-US')} يومًا`, `تبلغ سنة ${p.name} نحو ${p.yearDays.toLocaleString('en-US')} يومًا أرضيًا لأنه أبعد/أقرب نسبيًا في مداره حول الشمس.`, { topic: p.name });
  }
  if (kind === 2) {
    const withMoons = PLANETS.filter((p) => p.moons !== null);
    const p = pick(rng, withMoons);
    return numQ('space', `كم عدد أقمار كوكب ${p.name}؟`, p.moons ?? 0, `لكوكب ${p.name} ${p.moons === 0 ? 'لا أقمار معروفة له' : p.moons === 1 ? 'قمر واحد معروف' : `${p.moons} من الأقمار المعروفة`}.`, rng, { topic: p.name });
  }
  const four = shuffle(PLANETS, rng).slice(0, 4);
  const nearest = four.reduce((a, b) => (a.order < b.order ? a : b));
  return q('space', `أي الكواكب التالية هو الأقرب إلى الشمس؟`, four.map((p) => p.name), nearest.name, `${nearest.name} ترتيبه ${nearest.order} من الشمس، فهو الأقرب بين الخيارات الأربعة المعروضة.`, { topic: nearest.name });
}

function genWorldmap(rng: () => number): Question {
  const kind = ri(rng, 0, 2);
  const [country, capital, continentAr] = pick(rng, CAPITALS);
  if (kind === 0) {
    counter++;
    return {
      id: `gmap-${Date.now().toString(36)}-${counter}`,
      category: 'worldmap',
      type: 'map',
      text: `باستخدام الخريطة التفاعلية بالأسفل: في أي قارة تقع دولة «${country}»؟ اضغط على القارة الصحيحة.`,
      options: [],
      answer: 0,
      correctText: continentAr,
      continent: CONTINENT_TO_KEY[continentAr],
      explanation: `تقع ${country} (عاصمتها ${capital}) في قارة ${continentAr}.`,
      difficulty: 2,
      generated: true,
      topic: country,
      more: `عاصمة ${country} هي ${capital}، وتقع الدولة في قارة ${continentAr}.`,
    };
  }
  if (kind === 1) {
    return q('worldmap', `ما عاصمة ${country}؟`, opts4(capital, CAPITALS.map((c) => c[1]), rng), capital, `${capital} عاصمة ${country} الواقعة في ${continentAr}.`, { topic: country });
  }
  const [flagCountry, desc] = pick(rng, FLAGS);
  return q('worldmap', `علم أي دولة يتميز بالوصف التالي: ${desc}؟`, opts4(flagCountry, FLAGS.map((f) => f[0]), rng), flagCountry, `هذا وصف علم ${flagCountry}: ${desc}.`, { topic: `علم ${flagCountry}` });
}

function genImages(rng: () => number): Question {
  const [thing, person, year] = pick(rng, INVENTIONS);
  if (rng() < 0.5) {
    return q('images', `من صاحب هذا الإنجاز: ${thing}؟`, opts4(person, INVENTIONS.map((i) => i[1]), rng), person, `${thing} ينسب إلى ${person} (نحو عام ${year}م).`, { topic: person });
  }
  const pool = shuffle([year - 10, year + 15, year - 25, year + 40, year - 5], rng).slice(0, 3).map(String);
  return q('images', `في أي عام (تقريبًا) ظهر هذا الإنجاز: ${thing} على يد ${person}؟`, [String(year), ...pool], String(year), `ظهر ${thing} على يد ${person} نحو عام ${year}م.`, { topic: person });
}

function genOrdering(rng: () => number): Question {
  const chosen = shuffle(ORDER_EVENTS, rng).slice(0, 4).sort((a, b) => a[1] - b[1]);
  const events = chosen.map(([label, year]) => ({ label, year }));
  counter++;
  return {
    id: `gord-${Date.now().toString(36)}-${counter}`,
    category: 'ordering',
    type: 'order',
    text: 'رتّب الأحداث التاريخية التالية من الأقدم إلى الأحدث',
    options: [],
    answer: 0,
    correctText: events.map((e) => e.label).join(' ← '),
    events,
    explanation: `الترتيب الصحيح: ${events.map((e) => `${e.label} (${e.year < 0 ? `${Math.abs(e.year)} ق.م` : `${e.year}م`})`).join('، ثم ')}.`,
    difficulty: 2,
    generated: true,
    topic: events[0].label,
  };
}

function genHealth(rng: () => number): Question {
  const kind = ri(rng, 0, 3);
  if (kind === 0) {
    const [name, source] = pick(rng, NUTRIENTS);
    return q('health', `أي مصدر غذائي/طبيعي غني بـ«${name}»؟`, opts4(source, NUTRIENTS.map((n) => n[1]), rng), source, `من أغنى مصادر ${name}: ${source}.`, { topic: name });
  }
  if (kind === 1) {
    const [name, , effect] = pick(rng, NUTRIENTS);
    return q('health', `ما الأثر الشائع لنقص «${name}» في الجسم؟`, opts4(effect, NUTRIENTS.map((n) => n[2]), rng), effect, `نقص ${name} قد يؤدي إلى ${effect}، ويُعالج بتحسين الغذاء أو المكملات بإشراف طبي.`, { topic: name });
  }
  if (kind === 2) {
    const weight = ri(rng, 55, 95);
    const height = pick(rng, [1.6, 1.65, 1.7, 1.75, 1.8, 1.85]);
    const bmi = Math.round((weight / (height * height)) * 10) / 10;
    return numQ('health', `احسب مؤشر كتلة الجسم لشخص وزنه ${weight} كغ وطوله ${height} م (الوزن ÷ مربع الطول)؟`, bmi, `المؤشر = ${weight} ÷ (${height} × ${height}) = ${bmi}، والمعدل الطبيعي بين 18.5 و24.9.`, rng, { topic: 'مؤشر كتلة الجسم' });
  }
  const age = ri(rng, 15, 60);
  return numQ('health', `ما الحد الأقصى التقريبي لنبض القلب أثناء الجهد لعمر ${age} سنة (220 − العمر)؟`, 220 - age, `الحد الأقصى التقريبي = 220 − ${age} = ${220 - age} نبضة/دقيقة، وهي صيغة تقديرية شائعة في الطب الرياضي.`, rng, { topic: 'النبض الأقصى' });
}

function genSports(rng: () => number): Question {
  const kind = ri(rng, 0, 2);
  if (kind === 0) {
    const [year, winner] = pick(rng, WC_WINNERS);
    return q('sports', `من المنتخب الفائز بكأس العالم لكرة القدم عام ${year}؟`, opts4(winner, WC_WINNERS.map((w) => w[1]), rng), winner, `فاز منتخب ${winner} بكأس العالم لكرة القدم عام ${year}.`, { topic: `كأس العالم ${year}` });
  }
  if (kind === 1) {
    const winners = [...new Set(WC_WINNERS.map((w) => w[1]))];
    const team = pick(rng, winners);
    const years = WC_WINNERS.filter((w) => w[1] === team).map((w) => w[0]);
    const last = years[years.length - 1];
    return q('sports', `في أي عام فاز منتخب ${team} بكأس العالم لكرة القدم (آخر لقب له حتى 2022)؟`, opts4(String(last), WC_WINNERS.map((w) => String(w[0])), rng), String(last), `آخر ألقاب ${team} في كأس العالم حتى 2022 كان عام ${last} (ألقابه: ${years.join('، ')}).`, { topic: `منتخب ${team}` });
  }
  const [athlete, sport] = pick(rng, ATHLETES);
  return q('sports', `في أي رياضة اشتهر/اشتهرت «${athlete}»؟`, opts4(sport, ATHLETES.map((a) => a[1]), rng), sport, `${athlete} من أعلام رياضة ${sport}.`, { topic: athlete });
}

type GenFn = (rng: () => number) => Question;
const GENERATORS: Partial<Record<CategoryId, GenFn>> = {
  science: genScience,
  culture: genCulture,
  religion: genReligion,
  geohist: genGeohist,
  space: genSpace,
  worldmap: genWorldmap,
  images: genImages,
  ordering: genOrdering,
  health: genHealth,
  sports: genSports,
};

export const GENERATABLE_CATEGORIES: CategoryId[] = [
  'science', 'culture', 'religion', 'geohist', 'space', 'worldmap', 'images', 'puzzles', 'ordering', 'health', 'sports',
];

export function generateForCategory(
  category: CategoryId,
  count: number,
  seed: number,
  excludeTexts: Set<string> = new Set(),
  allowOrder = true,
): Question[] {
  const rng = mulberry32(seed >>> 0 || 1);
  const seen = new Set<string>(excludeTexts);
  const out: Question[] = [];
  let guard = 0;
  while (out.length < count && guard < count * 60) {
    guard++;
    let candidate: Question;
    if (category === 'puzzles') {
      candidate = generatePuzzle(rng, 2);
    } else {
      if (category === 'ordering' && !allowOrder) break;
      const fn = GENERATORS[category];
      if (!fn) break;
      candidate = fn(rng);
      // ترقيم معرفات فريدة إضافية لتجنب أي تشابه
      candidate.id = `${candidate.id}-${hashString(candidate.text).toString(36)}`;
    }
    // أسئلة الترتيب نصّها ثابت والأحداث متغيرة: يُستخدم توقيع الأحداث لمنع التكرار
    const sig = candidate.type === 'order' ? candidate.correctText : candidate.text;
    if (seen.has(sig)) continue;
    seen.add(sig);
    out.push(candidate);
  }
  return out;
}

export function generateMixedPack(
  count: number,
  seed: number,
  excludeTexts: Set<string> = new Set(),
  allowOrder = true,
): Question[] {
  const cats = shuffle(GENERATABLE_CATEGORIES.filter((c) => allowOrder || c !== 'ordering'), mulberry32((seed ^ 0x9e3779b9) >>> 0 || 1));
  const seen = new Set<string>(excludeTexts);
  const out: Question[] = [];
  let round = 0;
  while (out.length < count && round < 6) {
    for (const cat of cats) {
      if (out.length >= count) break;
      const got = generateForCategory(cat, 1, seed + round * 1009 + out.length * 131 + cat.length * 17, seen, allowOrder);
      for (const g of got) {
        seen.add(g.text);
        if (g.type === 'order') seen.add(g.correctText);
        out.push(g);
      }
    }
    round++;
  }
  return out.slice(0, count);
}

export default generateMixedPack;
