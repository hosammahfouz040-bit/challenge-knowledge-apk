import type { AppState } from '../types';
import { todayKey } from './utils';

const KEY = 'tahadi-alma3rifa-v1';

export const defaultState: AppState = {
  profile: {
    name: 'بطل المعرفة',
    avatar: 'graduation',
    xp: 0,
    totalPoints: 0,
    createdAt: new Date().toISOString(),
  },
  settings: {
    fontSize: 'md',
    sound: true,
    difficulty: 0,
    remotePackUrl: '',
  },
  stats: {
    games: 0,
    answered: 0,
    correct: 0,
    bestStreak: 0,
    bestScore: 0,
    perfectGames: 0,
    dailyDone: 0,
    reviewedCorrect: 0,
    bestSurvival: 0,
    perCategory: {},
    bestByMode: {},
  },
  history: [],
  wrong: [],
  usedIds: [],
  achievements: [],
  daily: { date: todayKey(), completed: false, score: 0 },
  customQuestions: [],
  onboarded: false,
};

export function loadState(): AppState {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return structuredClone(defaultState);
    const parsed = JSON.parse(raw) as Partial<AppState>;
    const merged: AppState = {
      ...structuredClone(defaultState),
      ...parsed,
      profile: { ...defaultState.profile, ...(parsed.profile ?? {}) },
      settings: { ...defaultState.settings, ...(parsed.settings ?? {}) },
      stats: {
        ...defaultState.stats,
        ...(parsed.stats ?? {}),
        perCategory: parsed.stats?.perCategory ?? {},
        bestByMode: parsed.stats?.bestByMode ?? {},
      },
      history: parsed.history ?? [],
      wrong: parsed.wrong ?? [],
      usedIds: parsed.usedIds ?? [],
      achievements: parsed.achievements ?? [],
      customQuestions: parsed.customQuestions ?? [],
      daily: parsed.daily ?? { date: todayKey(), completed: false, score: 0 },
    };
    // تجديد حالة التحدي اليومي عند تغير اليوم دون مسح أي تقدم
    if (merged.daily.date !== todayKey()) {
      merged.daily = { date: todayKey(), completed: false, score: 0 };
    }
    return merged;
  } catch {
    return structuredClone(defaultState);
  }
}

export function saveState(state: AppState) {
  try {
    localStorage.setItem(KEY, JSON.stringify(state));
  } catch {
    // مساحة التخزين ممتلئة: نحاول حفظ نسخة مخففة دون سجل طويل
    try {
      const light = { ...state, history: state.history.slice(0, 20), wrong: state.wrong.slice(0, 100) };
      localStorage.setItem(KEY, JSON.stringify(light));
    } catch {
      /* تجاهل: يبقى اللعب يعمل داخل الجلسة */
    }
  }
}

export function wipeState() {
  try {
    localStorage.removeItem(KEY);
  } catch {
    /* تجاهل */
  }
}
