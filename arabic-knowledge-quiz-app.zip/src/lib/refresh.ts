import type { CategoryId, Question } from '../types';
import { BANK } from '../data';
import { hashString } from './utils';
import { generatePuzzles } from './generator';

// تجديد بنك الأسئلة: آليات حقيقية موثقة —
// 1) جلب حزمة JSON من رابط يحدده المستخدم (مصدر حر يمتلك حق نشره) مع التحقق والتدقيق.
// 2) استيراد ملف حزمة JSON من الجهاز بنفس التحقق.
// 3) توليد ألغاز رقمية جديدة بإجابات محسوبة ومتحقق منها برمجيًا.
// لا تُضاف أي أسئلة وهمية ولا يُدّعى وجود مصدر تلقائي غير موجود.

const CATEGORY_IDS: CategoryId[] = ['science', 'culture', 'religion', 'geohist', 'space', 'worldmap', 'images', 'puzzles', 'ordering', 'health', 'sports'];

interface PackItem {
  text?: string;
  question?: string;
  options?: string[];
  choices?: string[];
  answer?: number;
  correctIndex?: number;
  correct?: string;
  correctText?: string;
  explanation?: string;
  category?: string;
  difficulty?: number;
}

export interface RefreshResult {
  added: Question[];
  skipped: number;
  error?: string;
}

function normalizeText(t: string): string {
  return t.replace(/\s+/g, ' ').replace(/[؟?،,.!«»""]/g, '').trim().toLowerCase();
}

export function validatePack(data: unknown, existing: Question[]): RefreshResult {
  const items: PackItem[] = Array.isArray(data)
    ? (data as PackItem[])
    : ((data as { questions?: PackItem[] })?.questions ?? []);
  if (!Array.isArray(items) || items.length === 0) {
    return { added: [], skipped: 0, error: 'صيغة الحزمة غير صالحة: توقّعنا قائمة أسئلة JSON.' };
  }
  const seen = new Set<string>();
  [...BANK, ...existing].forEach((q) => seen.add(normalizeText(q.text)));
  const added: Question[] = [];
  let skipped = 0;

  for (const it of items) {
    const text = (it.text ?? it.question ?? '').trim();
    const options = it.options ?? it.choices ?? [];
    let answerIdx = typeof it.answer === 'number' ? it.answer : typeof it.correctIndex === 'number' ? it.correctIndex : -1;
    const correctText = (it.correctText ?? it.correct ?? '').trim();
    if (answerIdx < 0 && correctText) answerIdx = options.indexOf(correctText);
    const valid =
      text.length >= 8 &&
      options.length === 4 &&
      new Set(options.map((o) => o.trim())).size === 4 &&
      answerIdx >= 0 && answerIdx < 4 &&
      !seen.has(normalizeText(text));
    if (!valid) {
      skipped++;
      continue;
    }
    seen.add(normalizeText(text));
    const cat = CATEGORY_IDS.includes(it.category as CategoryId) ? (it.category as CategoryId) : 'science';
    const diff = [1, 2, 3].includes(it.difficulty ?? 1) ? (it.difficulty as 1 | 2 | 3) : 1;
    added.push({
      id: `custom-${hashString(text).toString(36)}`,
      category: cat,
      type: 'mcq',
      text,
      options: [...options],
      answer: answerIdx,
      correctText: options[answerIdx],
      explanation: (it.explanation ?? 'إجابة موثقة من حزمة الأسئلة المستوردة.').trim(),
      difficulty: diff,
      custom: true,
      topic: options[answerIdx],
    });
  }
  return { added, skipped };
}

export async function fetchRemotePack(url: string, existing: Question[]): Promise<RefreshResult> {
  if (!url.trim()) {
    return { added: [], skipped: 0, error: 'أدخل رابط حزمة الأسئلة أولًا من الإعدادات.' };
  }
  if (typeof navigator !== 'undefined' && !navigator.onLine) {
    return { added: [], skipped: 0, error: 'لا يوجد اتصال بالإنترنت حاليًا. يمكنك الاستمرار باللعب بالأسئلة المحفوظة على جهازك دون اتصال.' };
  }
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 12000);
  try {
    const res = await fetch(url, { signal: controller.signal, headers: { Accept: 'application/json' } });
    if (!res.ok) return { added: [], skipped: 0, error: `تعذر الجلب من المصدر (رمز الاستجابة ${res.status}). تأكد من الرابط وحاول لاحقًا.` };
    const data: unknown = await res.json();
    return validatePack(data, existing);
  } catch {
    return { added: [], skipped: 0, error: 'فشل الاتصال بالمصدر. تحقق من الإنترنت أو الرابط، وسيستمر اللعب بالمحتوى المحلي المحفوظ.' };
  } finally {
    clearTimeout(timer);
  }
}

export function generatePuzzlePack(count: number): Question[] {
  return generatePuzzles(count, (Date.now() % 90000) + 7, 2).map((q) => ({ ...q, custom: true }));
}
