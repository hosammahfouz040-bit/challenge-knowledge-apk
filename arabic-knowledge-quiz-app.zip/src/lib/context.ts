import { createContext, useContext } from 'react';
import type { AppState, GameConfig } from '../types';
import type { Session } from './game';
import type { GameResult } from './progress';
import type { AchievementDef } from '../data/achievements';

export type View =
  | { name: 'home' }
  | { name: 'categories' }
  | { name: 'setup'; preset?: Partial<GameConfig> }
  | { name: 'quiz'; session: Session }
  | { name: 'results'; result: GameResult; unlocked: AchievementDef[]; leveledUp: boolean; dailyBonus: number }
  | { name: 'stats' }
  | { name: 'achievements' }
  | { name: 'profile' }
  | { name: 'search' }
  | { name: 'review' };

export interface AppContextValue {
  state: AppState;
  update: (fn: (s: AppState) => AppState) => void;
  view: View;
  go: (v: View) => void;
  startGame: (config: GameConfig) => void;
  startDaily: () => void;
  startReview: () => void;
  completeGame: (result: GameResult) => void;
  showToast: (msg: string) => void;
}

export const AppContext = createContext<AppContextValue | null>(null);

export function useApp(): AppContextValue {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used within AppContext.Provider');
  return ctx;
}
