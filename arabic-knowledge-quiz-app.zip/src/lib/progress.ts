import type { AnswerRecord, AppState, GameConfig } from '../types';
import { ACHIEVEMENTS, type AchievementDef } from '../data/achievements';
import { levelFromXp, todayKey, uid } from './utils';

export interface GameResult {
  config: GameConfig;
  categoryLabel: string;
  score: number;
  xpGain: number;
  records: AnswerRecord[];
  bestStreak: number;
  skipped: number;
}

export interface ApplyOutcome {
  next: AppState;
  unlocked: AchievementDef[];
  leveledUp: boolean;
  dailyBonus: number;
}

const DAILY_BONUS_XP = 30;

// تطبيق نتيجة لعبة على الحالة مرة واحدة فقط (تُستدعى عند إنهاء اللعبة حصرًا)
export function applyGameResult(state: AppState, result: GameResult): ApplyOutcome {
  const next: AppState = structuredClone(state);
  const total = result.records.length;
  const correct = result.records.filter((r) => r.correct).length;
  const mode = result.config.mode;

  let xpGain = result.xpGain;
  let dailyBonus = 0;

  // مكافأة التحدي اليومي تُمنح مرة واحدة فقط في اليوم
  if (mode === 'daily') {
    if (next.daily.date !== todayKey()) {
      next.daily = { date: todayKey(), completed: false, score: 0 };
    }
    if (!next.daily.completed) {
      next.daily.completed = true;
      next.daily.score = result.score;
      next.stats.dailyDone += 1;
      dailyBonus = DAILY_BONUS_XP;
      xpGain += DAILY_BONUS_XP;
    }
  }

  const levelBefore = levelFromXp(next.profile.xp);
  next.profile.xp += xpGain;
  next.profile.totalPoints += result.score;

  next.stats.games += 1;
  next.stats.answered += total;
  next.stats.correct += correct;
  next.stats.bestStreak = Math.max(next.stats.bestStreak, result.bestStreak);
  next.stats.bestScore = Math.max(next.stats.bestScore, result.score);
  if (total >= 5 && correct === total) next.stats.perfectGames += 1;
  next.stats.bestByMode[mode] = Math.max(next.stats.bestByMode[mode] ?? 0, result.score);
  if (mode === 'survival') {
    next.stats.bestSurvival = Math.max(next.stats.bestSurvival, correct);
  }

  // إحصاءات الأقسام ووسائل التعلم من الأخطاء
  const usedSet = new Set(next.usedIds);
  const wrongMap = new Map(next.wrong.map((w) => [w.id, w]));
  for (const r of result.records) {
    const cat = r.question.category;
    const cs = next.stats.perCategory[cat] ?? { answered: 0, correct: 0 };
    cs.answered += 1;
    if (r.correct) cs.correct += 1;
    next.stats.perCategory[cat] = cs;

    if (!r.question.generated) usedSet.add(r.question.id);

    if (mode === 'review') {
      if (r.correct) {
        wrongMap.delete(r.question.id);
        next.stats.reviewedCorrect += 1;
      }
    } else if (!r.correct) {
      if (!wrongMap.has(r.question.id)) wrongMap.set(r.question.id, r.question);
    }
  }
  next.usedIds = [...usedSet];
  next.wrong = [...wrongMap.values()].slice(-200);

  next.history = [
    {
      id: uid(),
      date: new Date().toISOString(),
      mode,
      categoryLabel: result.categoryLabel,
      score: result.score,
      total,
      correct,
    },
    ...next.history,
  ].slice(0, 50);

  const unlocked = ACHIEVEMENTS.filter((a) => !next.achievements.includes(a.id) && a.value(next) >= a.target);
  next.achievements = [...next.achievements, ...unlocked.map((u) => u.id)];

  return {
    next,
    unlocked,
    leveledUp: levelFromXp(next.profile.xp) > levelBefore,
    dailyBonus,
  };
}
